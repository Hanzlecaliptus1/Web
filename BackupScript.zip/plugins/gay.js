/**
Random Gay Bahaya Jir
Join Bang
https://chat.whatsapp.com/Bhwenfkc5Vi3V2kbTKw7WJ
Follow Channel 
https://whatsapp.com/channel/0029Vb6ru1s2Jl87BaI4RJ1H
**/
const axios = require('axios')

let handler = async (m, { conn }) => {
  try {
    await m.reply('⏳ Sedang mengambil foto...')

    const url = 'https://rynekoo-api.hf.space/random/nsfwhub/gay'
    const { data } = await axios.get(url, { responseType: 'arraybuffer' })

    await conn.sendMessage(m.chat, {
      image: data,
      caption: '✨ Foto berhasil diambil.'
    })
  } catch (e) {
    console.error(e)
    await m.reply('❌ Gagal mengambil foto.')
  }
}

handler.help = ['getgayfoto']
handler.tags = ['nsfw']
handler.command = /^getgayfoto$/i
handler.premium = false
handler.limit = 1

module.exports = handler