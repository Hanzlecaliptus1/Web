/*
  FITUR JPM CHANNEL WITH BUTTON (CommonJS)
  Fungsi: Broadcast ke banyak channel sekaligus dengan tombol Link.
  Teknik: Interactive Message (Native Flow).
*/

const { 
    generateWAMessageFromContent, 
    proto, 
    prepareWAMessageMedia 
} = require('@adiwajshing/baileys');

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
    // 1. Validasi Owner
    if (!isOwner) return m.reply('❌ *AKSES DITOLAK*\nFitur ini khusus Owner.');

    // --- KONFIGURASI (EDIT DI SINI) ---
    
    // A. Daftar ID Channel Tujuan (Berakhiran @newsletter)
    const targetChannels = [
        "120363400444882911@newsletter", // Channel 1
        "120363417446780608@newsletter"  // Channel 2
    ];

    // B. Konfigurasi Tombol
    const buttonConf = {
        displayText: "🔥 Order Sekarang", // Tulisan di tombol
        url: "https://wa.me/6283893616868", // Link tujuan (WA/Web)
        footer: "© Hanz Broadcast System" // Tulisan kecil di bawah
    };

    // ----------------------------------

    // 2. Validasi Pesan (Harus ada caption/text)
    let q = m.quoted ? m.quoted : m;
    let caption = text || q.text;

    if (!caption) {
        return m.reply(
            `⚠️ *FORMAT SALAH*\n\n` +
            `Caranya: Kirim/Reply Gambar/Video dengan caption, lalu ketik *${usedPrefix + command}*`
        );
    }

    let totalTarget = targetChannels.length;
    m.reply(`📢 *MEMULAI JPM BUTTON*\nTarget: ${totalTarget} Channel\nMohon tunggu...`);

    try {
        // 3. Siapkan Media (Jika ada)
        let mediaMessage = null;
        let mime = (q.msg || q).mimetype || '';

        if (/image|video/.test(mime)) {
            let mediaBuffer = await q.download();
            let mediaType = mime.includes('video') ? 'video' : 'image';
            
            mediaMessage = await prepareWAMessageMedia(
                { [mediaType]: mediaBuffer }, 
                { upload: conn.waUploadToServer }
            );
        }

        // 4. Buat Struktur Pesan Button (Hanya sekali render)
        // Kita buat fungsi generator pesan agar bisa dipanggil per-channel
        const createMsg = (jid) => {
            return generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            // Header: Media atau Kosong
                            header: proto.Message.InteractiveMessage.Header.create({
                                title: "",
                                subtitle: "",
                                hasMediaAttachment: !!mediaMessage,
                                ...(mediaMessage ? mediaMessage : {})
                            }),
                            
                            // Body: Isi Pesan Utama
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: caption
                            }),

                            // Footer
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: buttonConf.footer
                            }),

                            // Native Flow: Tombol Link (CTA)
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        "name": "cta_url",
                                        "buttonParamsJson": JSON.stringify({
                                            "display_text": buttonConf.displayText,
                                            "url": buttonConf.url,
                                            "merchant_url": buttonConf.url
                                        })
                                    }
                                ]
                            })
                        })
                    }
                }
            }, {});
        };

        // 5. Fungsi Delay
        const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        
        let sukses = 0;
        let gagal = 0;

        // 6. Eksekusi Broadcast
        for (let id of targetChannels) {
            try {
                await sleep(3000); // Delay 3 detik per channel

                let msg = createMsg(id);
                await conn.relayMessage(id, msg.message, { messageId: msg.key.id });
                
                sukses++;
            } catch (e) {
                console.log(`Gagal kirim ke ${id}:`, e);
                gagal++;
            }
        }

        // 7. Laporan Selesai
        m.reply(
            `✅ *JPM BUTTON SELESAI*\n\n` +
            `📨 Sukses: ${sukses}\n` +
            `🚫 Gagal: ${gagal}\n` +
            `📢 Total: ${totalTarget}`
        );

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan sistem saat memproses media.');
    }
};

handler.help = ['jpmchbutton'];
handler.tags = ['owner'];
handler.command = /^(jpmchbtn|jpmbutton|bcchbtn)$/i;
handler.owner = true;

module.exports = handler;