let axios = require('axios');

let handler = async (m, { conn, args }) => {
  try {
    // 1. Ambil teks dari input atau reply
    let text = args.join(' ');
    if (!text && m.quoted && m.quoted.text) text = m.quoted.text;
    
    // 2. Validasi jika tidak ada teks
    if (!text) throw 'Masukan teksnya! \nContoh: *.ttsjokowi Halo rakyatku*';
    if (text.length > 200) throw 'Teks kepanjangan, maksimal 200 karakter.';

    m.reply('Sabar ya, Pak Jokowi sedang rekaman...');

    // 3. Panggil fungsi TTS Jokowi
    let audioBuffer = await ttsJokowi(text);

    // 4. Kirim audio (menggunakan sendFile agar kompatibel dengan kode lamamu)
    // 'true' di parameter terakhir biasanya untuk mengirim sebagai Voice Note (PTT)
    conn.sendFile(m.chat, audioBuffer, 'jokowi.mp3', null, m, true);

  } catch (e) {
    console.log(e);
    m.reply('Gagal membuat audio. Coba lagi nanti atau teks terlalu aneh.');
  }
};

handler.help = ['ttsjokowi <teks>'];
handler.tags = ['tools'];
handler.command = /^(ttsjokowi|ttspakde)$/i; // Saya ubah command agar spesifik
module.exports = handler;

// Fungsi untuk mengambil audio dari API
async function ttsJokowi(text) {
  return new Promise(async (resolve, reject) => {
    try {
      // Menggunakan API eksternal (RVC Model)
      // Jika API ini mati, kamu perlu mengganti URL di bawah ini dengan API lain
      const { data } = await axios.get('https://skizo.tech/api/tts-anime', {
        params: {
          text: text,
          lang: 'id',
          voice: 'jokowi', // ID model untuk Jokowi
          apikey: 'bannned' // Ganti dengan API Key yang valid jika limit habis
        },
        responseType: 'arraybuffer' // Wajib arraybuffer untuk audio
      });
      
      resolve(data);
    } catch (e) {
      reject(e);
    }
  });
}