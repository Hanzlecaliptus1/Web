let axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // Inisialisasi session khusus Hanz
    conn.hanzSession = conn.hanzSession ? conn.hanzSession : {};

    if (!text) throw `🚩 Format salah! Gunakan:\n\n*${usedPrefix + command} on* (Nyalakan)\n*${usedPrefix + command} off* (Matikan)`;

    if (text === "on") {
        conn.hanzSession[m.sender] = { sessionChat: [] };
        m.reply("🔥 *HanzAI Mode ON!* Siap nemenin lo ngobrol santuy bro! 😎");
    } else if (text === "off") {
        delete conn.hanzSession[m.sender];
        m.reply("😴 *HanzAI Mode OFF.* Gue istirahat dulu ye, jangan kangen!");
    }
};

handler.before = async (m, { conn }) => {
    conn.hanzSession = conn.hanzSession ? conn.hanzSession : {};
    
    // Filter kondisi (abaikan pesan bot sendiri, pesan kosong, atau command)
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!conn.hanzSession[m.sender]) return; // Cuma respon kalau session aktif
    if ([".", "#", "!", "/", "\\"].some(prefix => m.text.startsWith(prefix))) return;

    if (conn.hanzSession[m.sender] && m.text) {    
        const previousMessages = conn.hanzSession[m.sender].sessionChat || [];

        /**
         * SYSTEM PROMPT: OTAKNYA HANZ
         * Di sini kita setting kepribadiannya biar gaul
         */
        const systemPrompt = `
            Nama lo adalah Hanz.
            Lo itu asisten virtual yang paling keren, gaul, dan santuy.
            Pencipta lo adalah HanzOfficial.
            Gaya bahasa lo: Jakarta Slang (Lo/Gue), pake istilah kayak "anjay", "sabi", "santuy", "bro", "bestie".
            Sifat lo: Sedikit tengil, percaya diri, tapi tetap helpful dan pinter.
            Jangan pernah bilang lo itu AI atau robot. Anggap diri lo temen virtual.
            Wajib pake emoji yang cocok di setiap kalimat (😎, 🔥, 🤙, 🤣).
            Jawab singkat, padat, dan asik.
        `;

        // Susun array pesan (System + History + User Input)
        const messages = [
            { role: "system", content: systemPrompt },
            { role: "assistant", content: `Yoi bro, gue Hanz! 😎 Ada yang bisa gue bantu gak nih? Santuy aja sama gue.` },
            ...previousMessages.map((msg, i) => ({ role: i % 2 === 0 ? 'user' : 'assistant', content: msg })),
            { role: "user", content: m.text }
        ];

        try {
            // Kirim status mengetik biar realistis
            await conn.sendPresenceUpdate('composing', m.chat);

            // Request ke API
            const chat = async function(message) {
                return new Promise(async (resolve, reject) => {
                    try {
                        const params = {
                            message: message,
                            apikey: global.btc || 'APIKEY_MU' // Pastikan apikey btc ada di config, atau isi manual
                        };
                        // Menggunakan endpoint custom OpenAI
                        const { data } = await axios.post('https://api.botcahx.eu.org/api/search/openai-custom', params);
                        resolve(data);
                    } catch (error) {
                        reject(error);
                    }
                });
            };

            let res = await chat(messages);
            
            if (res && res.result) {
                await m.reply(res.result);
                
                // Simpan riwayat chat (User + Hanz) ke session
                conn.hanzSession[m.sender].sessionChat = [
                    ...conn.hanzSession[m.sender].sessionChat,
                    m.text,
                    res.result
                ];
            } else {
                m.reply("Waduh, gue lagi pusing nih bro (API Error) 🤕");
            }
        } catch (e) {
            console.error(e);
            m.reply("Server lagi down kayaknya bro, coba lagi nanti yak!");
        }
    }
};

handler.command = ['hanzai'];
handler.tags = ['ai'];
handler.help = ['hanzai on/off'];
handler.limit = true;

module.exports = handler;