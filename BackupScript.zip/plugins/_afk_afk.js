let handler = async (m, { text }) => {
    let user = global.db.data.users[m.sender]
    
    // Simpan waktu AFK
    user.afk = + new Date
    // Simpan alasan (jika kosong, isi 'Tanpa Alasan')
    user.afkReason = text || 'Tanpa Alasan'
    
    // Buat kata-kata balasan
    // Menggunakan ternary operator: Jika ada text, tampilkan alasan. Jika tidak, kosongkan.
    let caption = `@${m.sender.split`@`[0]} sekarang AFK\n\n📝 *Alasan:* ${text ? text : 'Tanpa Alasan'}`

    // Kirim balasan dengan mention agar tag-nya aktif
    m.reply(caption, null, { mentions: [m.sender] })
}

handler.help = ['afk [alasan]']
handler.tags = ['main']
handler.command = /^afk$/i

module.exports = handler