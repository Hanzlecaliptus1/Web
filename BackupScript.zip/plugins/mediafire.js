const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  // 1. Validasi Input
  if (!text) return m.reply(`
⚠️ *Link MediaFire-nya mana?*

Contoh:
*${usedPrefix + command} https://www.mediafire.com/file/xxxxx/filename.zip/file*
  `.trim());

  // Validasi apakah link valid
  if (!/mediafire\.com/.test(text)) {
    return m.reply('❌ Link tidak valid! Harap masukkan link MediaFire yang benar.');
  }

  await m.reply('⏳ *Sedang memproses data file...*');

  try {
    // 2. Scraping Halaman MediaFire
    const data = await mediafireDl(text);

    if (!data || !data.link) {
      return m.reply('❌ Gagal mengambil link download. Kemungkinan file dihapus atau diproteksi password.');
    }

    // 3. Mengirim Informasi File
    const caption = `
📂 *MEDIAFIRE DOWNLOADER*

📝 *Nama:* ${data.name}
📊 *Ukuran:* ${data.size}
🔗 *Mime:* ${data.mime}

_Sedang mengirim file..._
_(Jika file terlalu besar, bot mungkin gagal mengirim dokumen)_
    `.trim();

    await m.reply(caption);

    // 4. Mengirim File (Document)
    // Batas aman bot biasanya sekitar 100MB tergantung settingan server/hosting Anda.
    await conn.sendMessage(m.chat, { 
      document: { url: data.link }, 
      fileName: data.name,
      mimetype: data.mime 
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply('❌ Terjadi kesalahan saat mengunduh atau file terlalu besar untuk dikirim via WhatsApp.');
  }
};

handler.help = ['mediafire'];
handler.command = /^(mediafire|mf)$/i;
handler.tags = ['downloader'];

module.exports = handler;

// --- FUNGSI SCRAPER MEDIAFIRE ---
async function mediafireDl(url) {
  try {
    const res = await axios.get(url);
    const $ = cheerio.load(res.data);

    // Mengambil Link Utama
    const link = $('a#downloadButton').attr('href');
    
    // Mengambil Ukuran File (Biasanya ada di dalam teks tombol download)
    // Contoh teks: "Download (10.5 MB)" -> Kita ambil yang dalam kurung
    const sizeText = $('a#downloadButton').text();
    const size = sizeText.replace(/[\r\n\t]+/g, '').match(/\((.*?)\)/)?.[1] || 'Unknown';

    // Mengambil Nama File
    // Biasanya ada di div dengan class 'dl-btn-label' atau dari link itu sendiri
    let name = $('div.dl-btn-label').attr('title');
    if (!name) {
        name = link.split('/').pop(); // Fallback ambil dari URL
    }

    // Menebak MimeType sederhana
    let mime = 'application/octet-stream';
    if (name.endsWith('.mp4')) mime = 'video/mp4';
    if (name.endsWith('.mp3')) mime = 'audio/mpeg';
    if (name.endsWith('.zip')) mime = 'application/zip';
    if (name.endsWith('.rar')) mime = 'application/x-rar-compressed';
    if (name.endsWith('.pdf')) mime = 'application/pdf';
    if (name.endsWith('.jpg') || name.endsWith('.jpeg')) mime = 'image/jpeg';
    if (name.endsWith('.png')) mime = 'image/png';
    if (name.endsWith('.apk')) mime = 'application/vnd.android.package-archive';

    return { name, size, link, mime };

  } catch (e) {
    console.error('Error scraping Mediafire:', e);
    return null;
  }
}