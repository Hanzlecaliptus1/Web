/*
  FITUR PRANK BUG / FAKE HACKING (CommonJS)
  Fungsi: Mengirim pesan drama hacking/virus boongan untuk menakut-nakuti teman.
  Aman: Tidak menyebabkan crash/lag.
*/

let handler = async (m, { conn, args, usedPrefix, command }) => {
    // 1. Target Prank
    let who;
    if (m.isGroup) {
        who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false;
    } else {
        who = m.chat;
    }

    if (!who) return m.reply(`⚠️ Tag atau Reply orang yang mau di-prank!\nContoh: *${usedPrefix + command} @temanmu*`);

    // 2. Pilihan Skenario Prank
    // Jika user mengetik .prankbug, bot akan memilih skenario secara acak
    const scenarios = [
        'virus', 'hack', 'banned'
    ];
    let type = scenarios[Math.floor(Math.random() * scenarios.length)];

    // Fungsi Delay
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    // --- SKENARIO 1: FAKE VIRUS ---
    if (type === 'virus') {
        await m.reply(`⚠️ *SYSTEM ALERT* ⚠️\n\nTerdeteksi aktivitas mencurigakan pada nomor @${who.split('@')[0]}...`, null, { mentions: [who] });
        await sleep(2000);
        
        await conn.sendMessage(m.chat, { text: `🔄 *Injecting Malware "Trojan.js"...*\n[▓▓░░░░░░░░] 20%` });
        await sleep(1500);
        
        await conn.sendMessage(m.chat, { text: `🔥 *Overheating CPU...*\n[▓▓▓▓▓▓░░░░] 60%` });
        await sleep(1500);
        
        await conn.sendMessage(m.chat, { text: `☠️ *Deleting System32...*\n[▓▓▓▓▓▓▓▓▓▓] 100%` });
        await sleep(2000);
        
        await conn.sendMessage(m.chat, { text: `✅ *HP MELEDAK DALAM 3 DETIK...*` });
        await sleep(1000);
        await conn.sendMessage(m.chat, { text: `3...` });
        await sleep(1000);
        await conn.sendMessage(m.chat, { text: `2...` });
        await sleep(1000);
        await conn.sendMessage(m.chat, { text: `1...` });
        await sleep(1000);
        
        await m.reply(`👊 *PRANK DOANG BANG!* 🤣\nJangan panik, HP lu aman.`);
    }

    // --- SKENARIO 2: FAKE HACKING ---
    else if (type === 'hack') {
        await m.reply(`💻 *MEMULAI PROTOKOL HACKING...*`);
        await sleep(2000);
        
        await conn.sendMessage(m.chat, { text: `📡 *Menghubungkan ke satelit NASA...*` });
        await sleep(2000);
        
        await conn.sendMessage(m.chat, { text: `🔓 *Membobol Chat History @${who.split('@')[0]}...*`, mentions: [who] });
        await sleep(2000);
        
        await conn.sendMessage(m.chat, { text: `📂 *Mengunduh Foto Galeri (Aib)...*` });
        await sleep(2000);
        
        await conn.sendMessage(m.chat, { text: `✅ *DATA BERHASIL DICURI!*` });
        await sleep(1000);
        
        await m.reply(`🤣 *CANDA BANG!*\nGak ada yang di-hack kok. Aman.`);
    }

    // --- SKENARIO 3: FAKE BANNED ---
    else if (type === 'banned') {
        // Mengirim pesan seolah-olah dari WhatsApp Official
        let fakeOfficial = {
            key: { fromMe: false, participant: `0@s.whatsapp.net`, remoteJid: 'status@broadcast' },
            message: { conversation: "WhatsApp Support" }
        };

        let textBan = `
🚫 *Nomor Anda Diblokir Sementara*

Kami mendeteksi pelanggaran pada nomor @${who.split('@')[0]}.
Akses WhatsApp Anda akan ditutup dalam 5 menit.

Reason: _Spamming & Bad Attitude_
Appeal: support@whatsapp.com
`.trim();

        await conn.sendMessage(m.chat, { text: textBan, mentions: [who] }, { quoted: fakeOfficial });
        
        await sleep(5000);
        await m.reply(`👻 *BOONGAN DENG!* 👻\nKaget gak? wkwkwk`);
    }
};

handler.help = ['prankbug @tag'];
handler.tags = ['fun'];
handler.command = /^(prankbug|fakebug|virusboongan|bug)$/i;

module.exports = handler;