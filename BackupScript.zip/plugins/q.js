process.env.TZ = 'Asia/Jakarta'
let fs = require('fs')
let path = require('path')
let fetch = require('node-fetch')
let moment = require('moment-timezone')
let levelling = require('../lib/levelling')

// --- DATABASE KATEGORI ---
let arrayMenu = [
  'all', 'ai', 'main', 'downloader', 'database', 'rpg', 'rpgG', 'sticker', 
  'advanced', 'xp', 'fun', 'game', 'github', 'group', 'image', 'nsfw', 
  'info', 'internet', 'islam', 'kerang', 'maker', 'news', 'owner', 'voice', 
  'quotes', 'store', 'stalk', 'shortlink', 'tools', 'anonymous', ''
]

const allTags = {
    'all': 'ALL MENU', 'ai': 'AI FEATURES', 'main': 'MAIN MENU', 
    'downloader': 'DOWNLOADER', 'database': 'DATABASE', 'rpg': 'RPG GAMES', 
    'rpgG': 'RPG GUILD', 'sticker': 'CONVERT & STICKER', 'advanced': 'ADVANCED', 
    'xp': 'EXP & LEVEL', 'fun': 'FUN MENU', 'game': 'GAMES', 'github': 'GITHUB', 
    'group': 'GROUP MENU', 'image': 'IMAGE TOOLS', 'nsfw': 'NSFW 18+', 
    'info': 'INFORMATION', 'internet': 'INTERNET', 'islam': 'ISLAMIC', 
    'kerang': 'KERANG AJAIB', 'maker': 'MAKER TOOLS', 'news': 'NEWS UPDATE', 
    'owner': 'OWNER ONLY', 'voice': 'VOICE CHANGER', 'quotes': 'QUOTES', 
    'store': 'STORE MENU', 'stalk': 'STALKING', 'shortlink': 'SHORTLINK', 
    'tools': 'TOOLS', 'anonymous': 'ANONYMOUS', '': 'OTHERS'
}

// Emoji Estetik untuk Slide
const tagEmojis = {
  'all': '💠', 'ai': '🤖', 'main': '⚡', 'downloader': '📥', 'database': '💾',
  'rpg': '⚔️', 'rpgG': '🏰', 'sticker': '🎫', 'advanced': '⚙️', 'xp': '📈',
  'fun': '🎡', 'game': '🎮', 'github': '🐱', 'group': '👥', 'image': '🖼️',
  'nsfw': '🔞', 'info': 'ℹ️', 'internet': '🌐', 'islam': '🕌', 'kerang': '🐚',
  'maker': '🎨', 'news': '📰', 'owner': '👑', 'voice': '🎙️', 'quotes': '💬',
  'store': '🛒', 'stalk': '🔎', 'shortlink': '🔗', 'tools': '🔧', 'anonymous': '🎭', '': '❓'
}

// --- CONFIG TAMPILAN (SLIDE STYLE) ---
const defaultMenu = {
    before: `
┏ ━ ❰ *DASHBOARD USER* ❱ ━
┃
┃ 👤 *Hi,* %name
┃ 🔭 *%ucapan*
┃
┃ 📈 *Level:* %level
┃ 🔮 *Role:* %role
┃ ⏳ *Uptime:* %uptime
┃ 📅 *Date:* %date
┗ ━━━━━━━━━━━━━━━━━━

 *S L I D E   M E N U*
`.trimStart(),
    header: '╭─── [ *%emoji %category* ]',
    body: '│ ◈ %cmd %islimit %isPremium',
    footer: '╰───────────────',
    after: `\n💡 *Tips:* Ketik %pmenu <kategori> untuk filter.`
}

function randomFooter() {
    const notes = [
      'Created with ❤️',
      'Simple & Fast Bot',
      'Gunakan dengan bijak',
      'Thanks for using this bot',
      'Have a great day!'
    ]
    return notes[Math.floor(Math.random() * notes.length)]
}

let handler = async (m, { conn, usedPrefix: _p, args = [], command }) => {
    try {
        // 1. DATA USER
        let package = JSON.parse(await fs.promises.readFile(path.join(__dirname, '../package.json')).catch(_ => '{}'))
        let userData = global.db && global.db.data && global.db.data.users ? global.db.data.users[m.sender] : {}
        let { exp = 0, limit = 0, level = 0, role = 'User' } = userData
        let { min, xp, max } = levelling.xpRange(level, global.multiplier || 1)
        
        // 2. WAKTU & UCAPAN
        let name = m.pushName || conn.getName(m.sender)
        let d = moment.tz('Asia/Jakarta')
        let date = d.format('DD MMMM YYYY')
        let time = d.format('HH:mm:ss')
        let hour = d.format('HH')
        let _uptime = process.uptime() * 1000
        let uptime = clockString(_uptime)
        
        let ucapan = 'Selamat Malam 🌙'
        if (hour >= 4 && hour < 11) ucapan = 'Selamat Pagi 🌄'
        else if (hour >= 11 && hour < 15) ucapan = 'Selamat Siang ☀️'
        else if (hour >= 15 && hour < 18) ucapan = 'Selamat Sore 🌇'

        let teks = args[0] || ''

        // 3. FAKE REPLY STATUS (Kunci Tampilan Keren)
        let fkontak = {
            key: {
                fromMe: false,
                participant: `0@s.whatsapp.net`, 
                ...(m.chat ? { remoteJid: `status@broadcast` } : {}) 
            },
            message: {
                contactMessage: {
                    displayName: `${name}`,
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
                }
            }
        }

        // 4. FILTER COMMANDS
        let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
            return {
                help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],
                tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
                prefix: 'customPrefix' in plugin,
                limit: plugin.limit,
                premium: plugin.premium,
                enabled: !plugin.disabled,
            }
        })

        // 5. PENYUSUNAN PESAN
        let text = ''
        if (!teks) {
            // Tampilan Awal (List Kategori)
            let totalCommands = help.reduce((acc, h) => acc + (h.help ? h.help.length : 0), 0)
            
            text = defaultMenu.before + `\n\n`
            // Loop kategori dibuat 2 kolom (opsional) atau list rapi
            for (let tag of arrayMenu) {
                if (tag && allTags[tag]) {
                    let emoji = tagEmojis[tag] ? tagEmojis[tag] : '🔹'
                    text += `│ ${emoji} ${_p}menu ${tag}\n`
                }
            }
            text += `╰━━━━━━━━━━━━━━━━━━\n\n🔖 *Total Fitur:* ${totalCommands}\n${randomFooter()}\n${defaultMenu.after}`
        } else {
            // Tampilan Spesifik Kategori
            if (!allTags[teks]) return m.reply(`❌ Kategori "${teks}" tidak ditemukan.`)
            
            text = defaultMenu.before + '\n\n'
            if (teks === 'all') {
                for (let tag of arrayMenu) {
                    if (tag !== 'all' && allTags[tag]) {
                        let emoji = tagEmojis[tag] ? tagEmojis[tag] + ' ' : ''
                        text += defaultMenu.header.replace(/%category/g, emoji + allTags[tag]) + '\n'
                        let categoryCommands = help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help)
                        for (let menu of categoryCommands) {
                            for (let helpCmd of menu.help) {
                                text += defaultMenu.body
                                    .replace(/%cmd/g, menu.prefix ? helpCmd : _p + helpCmd)
                                    .replace(/%islimit/g, menu.limit ? '(L)' : '')
                                    .replace(/%isPremium/g, menu.premium ? '(P)' : '') + '\n'
                            }
                        }
                        text += defaultMenu.footer + '\n'
                    }
                }
            } else {
                let emoji = tagEmojis[teks] ? tagEmojis[teks] + ' ' : ''
                text += defaultMenu.header.replace(/%category/g, emoji + allTags[teks]) + '\n'
                let categoryCommands = help.filter(menu => menu.tags && menu.tags.includes(teks) && menu.help)
                for (let menu of categoryCommands) {
                    for (let helpCmd of menu.help) {
                        text += defaultMenu.body
                            .replace(/%cmd/g, menu.prefix ? helpCmd : _p + helpCmd)
                            .replace(/%islimit/g, menu.limit ? '(L)' : '')
                            .replace(/%isPremium/g, menu.premium ? '(P)' : '') + '\n'
                    }
                }
                text += defaultMenu.footer + '\n'
            }
            text += '\n' + randomFooter()
        }

        // 6. REPLACE VARIABEL
        let replace = {
            '%': '%', p: _p, pmenu: `${_p}menu`, uptime, name, date, time, ucapan, level, role
        }
        let finalMessage = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])

        // 7. KIRIM PESAN (SLIDE CARD STYLE)
        await conn.sendMessage(m.chat, {
            text: finalMessage,
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    title: `🤖 ${ucapan}`,
                    body: `Click here for more info`,
                    thumbnailUrl: 'https://telegra.ph/file/b3a733452897086b31fc3-5aea104a505ff59ba4.jpg', // Ganti URL Gambarmu
                    sourceUrl: 'https://whatsapp.com/channel/0029VaJY...', // Ganti Link Channel/Group
                    mediaType: 1,
                    renderLargerThumbnail: true // Ini membuat tampilan gambar jadi BESAR (Slide Effect)
                }
            }
        }, { quoted: fkontak }) // Membalas seolah dari status

    } catch (e) {
        conn.reply(m.chat, 'Maaf, menu sedang error', m)
        console.error(e)
    }
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menuu|help)$/i
handler.exp = 3

module.exports = handler

function clockString(ms) {
    if (isNaN(ms)) return '--'
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}