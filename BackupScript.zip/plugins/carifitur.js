/*
  FITUR CARI COMMAND / SEARCH FEATURE (CommonJS)
  Fungsi: Mencari nama fitur/command yang tersedia di bot berdasarkan kata kunci.
  Cara kerja: Melakukan scanning pada global.plugins
*/

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Validasi Input
    if (!text) return m.reply(
        `⚠️ *Mau cari apa?*\n\n` +
        `Masukkan kata kunci fitur yang ingin dicari.\n` +
        `Contoh: *${usedPrefix + command}* sticker`
    );

    // 2. Ambil Database Plugin
    // Mengakses variabel global.plugins yang memuat semua script
    let plugins = Object.values(global.plugins);
    let search = text.toLowerCase();
    let results = [];

    // 3. Mulai Searching
    // Melakukan loop ke semua file plugin
    for (let plugin of plugins) {
        // Pastikan plugin punya properti 'help' (daftar command bantuan)
        if (plugin.help && Array.isArray(plugin.help)) {
            for (let help of plugin.help) {
                // Jika command mengandung kata kunci pencarian
                if (help && help.toLowerCase().includes(search)) {
                    results.push(help);
                }
            }
        }
    }

    // 4. Cek Hasil
    if (results.length === 0) {
        return m.reply(`❌ Fitur dengan kata kunci *"${text}"* tidak ditemukan.`);
    }

    // 5. Susun Tampilan
    let total = results.length;
    let header = `🔍 *PENCARIAN FITUR* 🔍\n` +
                 `🔑 Kata Kunci: *${text}*\n` +
                 `📊 Ditemukan: *${total}* Command\n` +
                 `━━━━━━━━━━━━━━━━━━\n`;

    // Mapping hasil menjadi list
    let body = results.map((cmd, i) => {
        return `│ ${i + 1}. *${usedPrefix}${cmd}*`;
    }).join('\n');

    let footer = `\n━━━━━━━━━━━━━━━━━━\n_Ketik command di atas untuk menggunakan._`;

    // 6. Kirim Pesan
    await conn.sendMessage(m.chat, {
        text: header + body + footer,
        contextInfo: {
            externalAdReply: {
                title: "Fitur Search Engine",
                body: `Hasil pencarian untuk: ${text}`,
                thumbnailUrl: "https://telegra.ph/file/0b322435553b04186b786.png", // Ganti gambar kaca pembesar jika ada
                sourceUrl: "https://whatsapp.com/channel/0029VbB8WYS4CrfhJCelw33j",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
};

handler.help = ['carifitur <keyword>', 'find <keyword>'];
handler.tags = ['info', 'tools'];
handler.command = /^(carifitur|find|search|cari)$/i;

module.exports = handler;