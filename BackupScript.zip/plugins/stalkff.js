/*
  FITUR STALK FREE FIRE (CommonJS)
  Fungsi: Mengecek Nickname berdasarkan User ID.
  API: Agatz (Free Public)
*/

const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Validasi Input
    if (!text) return m.reply(
        `⚠️ Masukkan ID Free Fire!\n\n` +
        `Contoh:\n*${usedPrefix + command}* 12345678`
    );

    // Cek apakah input hanya angka
    if (isNaN(text)) return m.reply('❌ ID harus berupa angka!');

    m.reply('⏳ *Sedang mengecek ID ke server Garena...*');

    try {
        // 2. Request ke API (Menggunakan API Agatz/Kyuurzy/Sejenis yang stabil)
        // Endpoint ini biasanya mengambil data dari gateway Topup
        const { data } = await axios.get(`https://api.agatz.xyz/api/game/ff?id=${text}`);

        // 3. Cek Validitas
        if (!data || !data.nickname) {
            return m.reply('❌ ID tidak ditemukan atau Server sedang gangguan.');
        }

        // 4. Ambil Data
        let nickname = data.nickname;
        let id = data.id || text; // Kadang API balikin ID, kadang tidak
        
        // Gambar Banner FF (Bisa diganti)
        let thumb = "https://telegra.ph/file/8834f6d83f32935f257c9.jpg"; 

        // 5. Susun Pesan
        let caption = `
┏─── [ *FREE FIRE STALK* ] ───
│
│ 👤 *Nickname :* ${nickname}
│ 🆔 *ID Player :* ${id}
│ 🎮 *Game :* Garena Free Fire
│
┗──────────────────────
_Data diambil berdasarkan ID Server._
`.trim();

        // 6. Kirim Hasil
        await conn.sendMessage(m.chat, {
            image: { url: thumb },
            caption: caption,
            contextInfo: {
                externalAdReply: {
                    title: "✅ Valid Account",
                    body: nickname,
                    thumbnailUrl: thumb,
                    sourceUrl: "https://ff.garena.com/",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan. Pastikan ID benar atau API sedang down.');
    }
};

handler.help = ['stalkff <id>', 'cekidff <id>'];
handler.tags = ['internet', 'game'];
handler.command = /^(stalkff|cekidff|checkff|ff)$/i;

module.exports = handler;