/*
  COMMAND SULAP (KICK WITH STYLE)
  Type: CommonJS
  Author: Hanz (Edited by AI)
*/

let handler = async (m, { conn, isOwner, isAdmin, args }) => {
  // 1. Validasi Pesan Bot Sendiri
  if (m.isBaileys) return;

  // 2. Validasi Admin/Owner
  if (!(isAdmin || isOwner)) {
    global.dfail('admin', m, conn);
    throw false;
  }

  // 3. Tentukan Target yang mau disulap
  let users = [];
  let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";

  if (m.quoted) {
    // Jika reply pesan target
    users.push(m.quoted.sender);
  } else if (m.mentionedJid && m.mentionedJid.length > 0) {
    // Jika tag target
    users = m.mentionedJid;
  } else {
    throw `🎩 *MAGIC FAIL*\n\nMana sukarelawannya?\nTag atau Reply orang yang mau dihilangkan! 🪄`;
  }

  // 4. Filter Target (Agar tidak kick Owner Grup / Bot Sendiri)
  users = users.filter(
    (u) => !(u === ownerGroup || u.includes(conn.user.jid))
  );

  if (users.length === 0) {
    return m.reply("🛡️ *ANTI-MAGIC*\nEits! Orang sakti (Owner/Bot) tidak mempan disulap!");
  }

  // --- MULAI PERTUNJUKAN SULAP ---

  // Tahap 1: Intro
  await conn.sendMessage(m.chat, { 
      text: "🎩 *THE MAGIC SHOW* 🎩\n\nLadies and Gentlemen, perhatikan user ini baik-baik...",
      mentions: users 
  }, { quoted: m });

  // Delay sedikit biar tegang (2 detik)
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Tahap 2: Mantra
  await conn.sendMessage(m.chat, { text: "✨ *SIMSALABIM!* ✨" });
  
  // Delay lagi (1 detik)
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Tahap 3: Eksekusi Kick
  for (let user of users) {
    if (user.endsWith("@s.whatsapp.net")) {
      await conn.groupParticipantsUpdate(m.chat, [user], "remove");
    }
  }

  // Tahap 4: Ending
  await conn.sendMessage(m.chat, { text: "💨 *POOF!* \nDia menghilang tanpa jejak! 🐇" });

};

handler.help = ['sulap @user'];
handler.tags = ['group'];
// Command regex: sulap, magic, atau vanish
handler.command = /^(sulap|magic|vanish)$/i;

handler.group = true;
handler.botAdmin = true;

module.exports = handler;