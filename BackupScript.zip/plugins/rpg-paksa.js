let handler = async (m, { conn, text }) => {
    let user = global.db.data.users[m.sender]
    let name = conn.getName(m.sender)
    let id = m.sender
    
    // --- KONFIGURASI ---
    let cooldown = 7200000 // 2 Jam
    let timers = (new Date() - (user.lastngewe || 0))
    let remaining = cooldown - timers

    // --- CEK MISI AKTIF ---
    conn.misi = conn.misi ? conn.misi : {}
    if (id in conn.misi) {
        return conn.reply(m.chat, `⚠️ Kamu masih dalam sesi *${conn.misi[id][0]}*! Selesaikan dulu atau tunggu sampai lemasnya hilang.`, m)
    }

    // --- CEK COOLDOWN ---
    if (timers > cooldown || !user.lastngewe) {
        // Reward Gacha
        let rewardMoney = Math.floor(Math.random() * 1000000) + 500000
        let rewardExp = Math.floor(Math.random() * 10000) + 1000
        
        // Target (Jika ada tag, gunakan nama tag, jika tidak gunakan 'Pasangan')
        let target = m.mentionedJid && m.mentionedJid[0] ? conn.getName(m.mentionedJid[0]) : "Pasanganmu"

        // --- NARASI STORY ---
        let story = [
            `🔥 *Mulai memanaskan suasana...*\nKamu mengajak ${target} ke dalam kamar...`, // 0 detik
            `💋 *Foreplay...*\nKamu mulai mencium leher dan meremas area sensitifnya... desahan mulai terdengar.`, // 10 detik
            `🥵 *Masuk...*\n"Ahhh... pelan-pelan sayang..."\nKamu mulai memasukinya perlahan...`, // 15 detik
            `💦 *Genjot Terus...*\n"Lebih cepattt!! Ahhh sakhitt tapi enaaakkk!!" >///<`, // 20 detik
            `🌊 *Puncak Kenikmatan...*\n"Ahhh.. aku mau keluaarrr!!"\n💦💦 *CROTTT DI DALAM!*` // 25 detik
        ]

        // --- EKSEKUSI MISI ---
        conn.misi[id] = [
            'Wikwik',
            setTimeout(() => {
                delete conn.misi[id]
            }, 27000)
        ]

        // Kirim Narasi Bertahap
        setTimeout(() => { m.reply(story[0]) }, 0)
        setTimeout(() => { m.reply(story[1]) }, 10000)
        setTimeout(() => { m.reply(story[2]) }, 15000)
        setTimeout(() => { m.reply(story[3]) }, 20000)
        setTimeout(() => { m.reply(story[4]) }, 25000)

        // --- PEMBERIAN HADIAH (ENDING) ---
        setTimeout(async () => {
            user.money += rewardMoney
            user.exp += rewardExp
            
            let caption = `
🥵 *PUAS MAKSIMAL* 🥵
━━━━━━━━━━━━━━━━━━
👤 *Player:* ${name}
❤️ *Partner:* ${target}

📊 *HASIL PERGULATAN:*
💰 Uang: +Rp ${rewardMoney.toLocaleString()}
✨ Exp: +${rewardExp.toLocaleString()}
🔋 Stamina: -20
━━━━━━━━━━━━━━━━━━
_Lutut getar, hati senang. Istirahat dulu bos!_
`.trim()

            // Kirim dengan Thumbnail (AdReply)
            await conn.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    externalAdReply: {
                        title: "Sesi Ena-Ena Selesai",
                        body: "Mantap Bang!",
                        thumbnailUrl: "https://telegra.ph/file/a786b4269db88249a4972.jpg", // Ganti URL gambar yang sesuai/hot (tapi aman)
                        sourceUrl: "https://whatsapp.com/channel/0029VbB8WYS4CrfhJCelw33j",
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m })
            
            user.lastngewe = new Date() * 1
        }, 27000)

    } else {
        // Pesan Cooldown
        let timeStr = clockString(remaining)
        m.reply(`🕒 *Lagi Lemas Bos!*
        
Kamu baru saja 'olahraga malam'.
Isi tenaga dulu, tunggu selama:
*${timeStr}*
        
_Jangan maksa, nanti encok._`)
    }
}

handler.help = ['wikwik @tag', 'enaena']
handler.tags = ['rpg', 'nsfw']
handler.command = /^(wikwik|enaena|ngewe|anu)$/i
handler.register = true
handler.group = true

module.exports = handler

// --- Helper Waktu ---
function clockString(ms) {
    let h = Math.floor(ms / 3600000)
    let m = Math.floor(ms / 60000) % 60
    let s = Math.floor(ms / 1000) % 60
    return [h, 'Jam', m, 'Menit', s, 'Detik'].map(v => v.toString().padStart(2, 0)).join(' ')
}