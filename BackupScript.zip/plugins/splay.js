const fetch = require('node-fetch')

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Mau play lagu apa?\n\n*Contoh:*\n${usedPrefix + command} sparks`
    )
  }

  try {
    await conn.sendMessage(m.chat, { react: { text: '🎧', key: m.key } })

    const api = `https://api.deline.web.id/downloader/spotifyplay?q=${encodeURIComponent(text)}`
    const res = await fetch(api)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)

    const json = await res.json()

    if (!json.status || !json.result) {
      return m.reply('Gagal mengambil data dari Spotify, coba lagi nanti.')
    }

    const { metadata = {}, dlink } = json.result
    const {
      title = '-',
      artist = '-',
      duration = '-',
      cover = '',
      url = ''
    } = metadata

    if (!dlink) return m.reply('Link audio tidak ditemukan.')

    const caption = `*© Spotify Play*

*Judul:* ${title}
*Artis:* ${artist}
*Durasi:* ${duration}`

    await conn.sendMessage(
      m.chat,
      {
        text: caption,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: title || 'Spotify Music',
            body: artist || 'Spotify Track',
            mediaType: 1,
            thumbnailUrl: cover,
            sourceUrl: 'https://api.deline.web.id/',
            renderLargerThumbnail: true,
            showAdAttribution: false
          }
        }
      },
      { quoted: m }
    )

    await conn.sendMessage(
      m.chat,
      {
        audio: { url: dlink },
        mimetype: 'audio/mp4',
        fileName: `${title || 'spotify'}.mp3`
      },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    m.reply('Terjadi kesalahan saat memproses permintaan.')
  }
}

handler.tags = ['downloader']
handler.help = ['spotifyplay']
handler.command = /^(splay)$/i
handler.limit = true
handler.register = true

module.exports = handler