/*
  FITUR TO MONYET (FFMPEG STABIL)
  Fix: Download aset overlay ke lokal dulu biar gak error.
*/

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!/image/.test(mime)) {
        return m.reply(`⚠️ Kirim/Reply foto temanmu dengan caption: *${usedPrefix + command}*`);
    }

    m.reply('⏳ Sedang memproses (Mode Stabil)...');

    try {
        // 1. Setup Path File Sementara
        let getRandom = (ext) => `${Math.floor(Math.random() * 10000)}${ext}`;
        let tmpDir = path.join(__dirname, '../tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

        let fileUser = path.join(tmpDir, getRandom('.jpg'));
        let fileMonkey = path.join(tmpDir, getRandom('.png'));
        let fileOutput = path.join(tmpDir, getRandom('.jpg'));

        // 2. Download Gambar User
        let imgBuffer = await q.download();
        fs.writeFileSync(fileUser, imgBuffer);

        // 3. Download Gambar Monyet (Secara Manual)
        // Ini solusi agar FFMPEG tidak error membaca URL
        let monkeyUrl = 'https://files.catbox.moe/02z1zw.png';
        let response = await axios.get(monkeyUrl, { responseType: 'arraybuffer' });
        fs.writeFileSync(fileMonkey, response.data);

        // 4. Jalankan FFMPEG dengan File Lokal
        // - [1][0]scale2ref : Samakan ukuran monyet (1) dengan user (0)
        // - format=rgba : Pastikan ada alpha channel
        // - colorchannelmixer=aa=0.6 : Transparansi 60%
        // - overlay : Tempel
        let cmd = `ffmpeg -i "${fileUser}" -i "${fileMonkey}" -filter_complex "[1:v][0:v]scale2ref[over][base];[over]format=rgba,colorchannelmixer=aa=0.6[over_trans];[base][over_trans]overlay=0:0" -y "${fileOutput}"`;

        exec(cmd, async (error, stdout, stderr) => {
            // Hapus file input (User & Monyet) untuk hemat ruang
            if (fs.existsSync(fileUser)) fs.unlinkSync(fileUser);
            if (fs.existsSync(fileMonkey)) fs.unlinkSync(fileMonkey);

            if (error) {
                console.error("[FFMPEG ERROR]:", stderr);
                return m.reply('❌ Gagal render. Pastikan `ffmpeg` sudah terinstall di panel/vps kamu.\nKetik di terminal: apt install ffmpeg');
            }

            // 5. Kirim Hasil
            let buff = fs.readFileSync(fileOutput);
            
            await conn.sendMessage(m.chat, {
                image: buff,
                caption: '🐵 Wajah aslinya mulai terlihat...'
            }, { quoted: m });

            // Hapus output
            if (fs.existsSync(fileOutput)) fs.unlinkSync(fileOutput);
        });

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat download gambar.');
    }
};

handler.help = ['tomonyet'];
handler.tags = ['maker', 'fun'];
handler.command = /^(tomonyet|monyet)$/i;

module.exports = handler;