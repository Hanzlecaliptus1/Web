let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Validasi Input
    if (!text) return m.reply(
        `⚠️ *Format Salah!*\n\n` +
        `Masukkan Link Grup WhatsApp.\n` +
        `Contoh: *${usedPrefix + command} https://chat.whatsapp.com/D8s82xxxxxx*`
    );

    // Cek apakah teks mengandung link WA
    if (!text.includes('chat.whatsapp.com')) return m.reply('❌ Link tidak valid! Pastikan link diawali chat.whatsapp.com');

    m.reply('🔍 *Sedang menganalisa link grup...*');

    try {
        // 2. Ambil Kode Invite dari Link
        // Regex untuk mengambil kode unik setelah slash '/'
        let regex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i;
        let [_, code] = text.match(regex) || [];

        if (!code) return m.reply('❌ Kode invite tidak terbaca. Pastikan link benar.');

        // 3. Request Data ke WhatsApp Server
        const res = await conn.groupGetInviteInfo(code);

        // 4. Ambil Foto Profil Grup (Jika ada)
        let ppgc;
        try {
            ppgc = await conn.profilePictureUrl(res.id, 'image');
        } catch {
            ppgc = 'https://telegra.ph/file/bf9652445dcb96ffca9c9-6edbcd1425dac25f09.jpg'; // Default jika tidak ada foto/privasi
        }

        // 5. Format Tanggal Pembuatan
        let date = new Date(res.creation * 1000).toLocaleDateString('id-ID', {
            day: 'numeric', month: 'long', year: 'numeric'
        });

        // 6. Susun Laporan
        let caption = `🆔 *GROUP ID INSPECTOR (BY LINK)*\n\n` +
                      `📛 *Nama:* ${res.subject}\n` +
                      `🔑 *ID Grup:* \`${res.id}\`\n\n` +
                      `👑 *Pembuat:* @${res.owner ? res.owner.split('@')[0] : 'Tidak Diketahui'}\n` +
                      `📅 *Dibuat:* ${date}\n` +
                      `👥 *Estimasi Member:* ${res.size || '?'}\n\n` +
                      `📝 *Deskripsi:*\n${res.desc || '- Tidak ada -'}`;

        // 7. Kirim Hasil
        await conn.sendMessage(m.chat, {
            image: { url: ppgc },
            caption: caption,
            contextInfo: {
                mentionedJid: res.owner ? [res.owner] : [],
                externalAdReply: {
                    title: "Group Metadata",
                    body: res.subject,
                    thumbnailUrl: ppgc,
                    sourceUrl: text, // Link ke grupnya
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('❌ *Gagal!* Link mungkin sudah di-reset (revoked), kadaluarsa, atau bot dilarang mengakses info grup ini.');
    }
};

handler.help = ['cekidgc <link>', 'inspectgc'];
handler.tags = ['tools', 'group'];
handler.command = /^(cekidgc|inspectgc|idgclink)$/i;

module.exports = handler;