/*
  FITUR PENCARI FILM IMDB (CommonJS)
  Sumber Data: OMDB API
  Fungsi: Menampilkan detail film, rating, cast, dan poster.
*/

const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Validasi Input
    if (!text) return m.reply(
        `🎬 *IMDB SEARCH*\n\n` +
        `Kirim judul film yang ingin dicari.\n` +
        `Contoh:\n*${usedPrefix + command}* Avengers Endgame\n*${usedPrefix + command}* Interstellar`
    );

    m.reply('🍿 Sedang mencari info film...');

    try {
        // 2. Konfigurasi API
        // Saya menggunakan API Key publik gratis. 
        // Jika limit habis, Anda bisa daftar gratis di www.omdbapi.com dan ganti key di bawah.
        let apiKey = 'e13557f'; 
        let query = encodeURIComponent(text);
        
        // 3. Request Data
        let res = await axios.get(`http://www.omdbapi.com/?apikey=${apiKey}&t=${query}&plot=full`);
        let json = res.data;

        // 4. Cek Apakah Film Ditemukan
        if (json.Response === 'False') {
            return m.reply('❌ Film tidak ditemukan! Coba pastikan ejaan judulnya benar (Bahasa Inggris).');
        }

        // 5. Ambil Rating IMDB
        let imdbRating = json.Ratings.find(r => r.Source === "Internet Movie Database")?.Value || json.imdbRating || "N/A";
        let rottenTomatoes = json.Ratings.find(r => r.Source === "Rotten Tomatoes")?.Value || "N/A";

        // 6. Susun Caption
        let caption = `🎬 *IMDB MOVIE INFO* 🎬\n` +
                      `━━━━━━━━━━━━━━━━━━\n` +
                      `📺 *Judul:* ${json.Title}\n` +
                      `🗓️ *Tahun:* ${json.Year}\n` +
                      `⏱️ *Durasi:* ${json.Runtime}\n` +
                      `🎭 *Genre:* ${json.Genre}\n` +
                      `⭐ *Rating:* ${imdbRating}\n` +
                      `🍅 *Rotten Tomatoes:* ${rottenTomatoes}\n` +
                      `🔞 *Rated:* ${json.Rated}\n` +
                      `🏆 *Awards:* ${json.Awards}\n` +
                      `━━━━━━━━━━━━━━━━━━\n` +
                      `🎥 *Sutradara:* ${json.Director}\n` +
                      `✍️ *Penulis:* ${json.Writer}\n` +
                      `👥 *Aktor:* ${json.Actors}\n` +
                      `━━━━━━━━━━━━━━━━━━\n` +
                      `📝 *SINOPSIS:*\n${json.Plot}\n` +
                      `━━━━━━━━━━━━━━━━━━\n` +
                      `_Powered by OMDB API_`;

        // 7. Kirim Poster & Caption
        // Cek apakah ada poster valid
        let posterUrl = (json.Poster && json.Poster !== 'N/A') 
            ? json.Poster 
            : 'https://telegra.ph/file/405d38758c8e3744c171f.jpg'; // Fallback image jika tidak ada poster

        await conn.sendMessage(m.chat, {
            image: { url: posterUrl },
            caption: caption
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat mengambil data film.');
    }
};

handler.help = ['imdb <judul>'];
handler.tags = ['internet', 'tools'];
handler.command = /^(imdb|film|movie)$/i;

module.exports = handler;