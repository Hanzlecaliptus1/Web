/*
  FITUR PRANK SYSTEM DELAY (CommonJS)
  Fungsi: Bot berpura-pura membuat grup lag/delay (Hanya Akting).
  Aman: Tidak mengirim virtex/sampah biner.
*/

let handler = async (m, { conn }) => {
    // Fungsi Delay
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    // 1. Peringatan Awal
    await m.reply(`⚠️ *SYSTEM WARNING* ⚠️\n\nMemulai protokol pembebanan server...\nTarget: ${m.chat}`);
    
    // 2. Simulasi Loading (Typing...)
    // Bot akan terlihat "sedang mengetik" lama sekali
    await conn.sendPresenceUpdate('composing', m.chat);
    await sleep(5000); // Tahan 5 detik

    // 3. Kirim Pesan "Lag"
    await conn.sendMessage(m.chat, { text: `🔄 *Injecting 100.000 Spam Packets...*\nWait...` });
    
    await conn.sendPresenceUpdate('composing', m.chat);
    await sleep(4000); 

    await conn.sendMessage(m.chat, { text: `🔥 *CPU OVERHEAT 99%* 🔥\nGrup akan freeze dalam 3 detik.` });
    
    await sleep(2000);
    await conn.sendMessage(m.chat, { text: `3...` });
    await sleep(2000); // Delay buatan biar kerasa berat
    await conn.sendMessage(m.chat, { text: `2...` });
    await sleep(2000);
    await conn.sendMessage(m.chat, { text: `1...` });
    await sleep(3000);

    // 4. Plot Twist (Ending)
    await conn.sendMessage(m.chat, { 
        text: `👻 *PRANK BANG!* 🤣\n\nGak ada yang lag kok. HP lu aman jaya.\nJangan tegang gitu lah.` 
    }, { quoted: m });

    // Matikan status mengetik
    await conn.sendPresenceUpdate('available', m.chat);
};

handler.help = ['bugdelay', 'grouplag'];
handler.tags = ['fun'];
handler.command = /^(bugdelay|grouplag|pranklag)$/i;
handler.group = true; // Hanya bisa di grup

module.exports = handler;