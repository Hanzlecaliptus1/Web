/*
  FITUR WHICH PLUGIN (CommonJS)
  Fungsi: Mencari letak file plugin berdasarkan nama command/perintah.
  Contoh: .cpcmd sticker -> Hasil: "Command sticker ada di file maker-sticker.js"
  Akses: KHUSUS OWNER.
*/

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
    // 1. Validasi Owner
    if (!isOwner) return m.reply('❌ *AKSES DITOLAK*\nFitur ini khusus Owner untuk maintenance sistem.');

    // 2. Validasi Input
    if (!text) return m.reply(
        `⚠️ *Command apa yang dicari?*\n\n` +
        `Contoh: *${usedPrefix + command}* sticker\n` +
        `(Bot akan mencari file mana yang menghandle command 'sticker')`
    );

    m.reply('🔍 *Sedang melacak command...*');

    // 3. Ambil Semua Plugin
    let plugins = global.plugins;
    let found = [];
    let inputCmd = text.toLowerCase();

    // 4. Looping & Matching Logic
    for (let filename in plugins) {
        let plugin = plugins[filename];

        // Cek apakah plugin punya properti 'command'
        if (plugin.command) {
            // A. Jika command berbentuk RegExp (Standar Bot)
            if (plugin.command instanceof RegExp) {
                // Kita tes apakah input user cocok dengan regex command tersebut
                if (plugin.command.test(inputCmd)) {
                    found.push({
                        file: filename.replace(/^.*[\\/]/, ''), // Ambil nama file saja
                        type: 'RegExp',
                        cmd: plugin.command.toString()
                    });
                }
            } 
            // B. Jika command berbentuk Array (Beberapa base bot pakai ini)
            else if (Array.isArray(plugin.command)) {
                if (plugin.command.includes(inputCmd)) {
                    found.push({
                        file: filename.replace(/^.*[\\/]/, ''),
                        type: 'Array',
                        cmd: plugin.command.join(', ')
                    });
                }
            }
            // C. Jika command String biasa
            else if (typeof plugin.command === 'string') {
                if (plugin.command === inputCmd) {
                    found.push({
                        file: filename.replace(/^.*[\\/]/, ''),
                        type: 'String',
                        cmd: plugin.command
                    });
                }
            }
        }
    }

    // 5. Tampilkan Hasil
    if (found.length === 0) {
        return m.reply(`❌ Command *"${text}"* tidak ditemukan di file plugin manapun.\nMungkin itu fitur bawaan (case) di main.js atau command belum terdaftar.`);
    }

    let caption = `📂 *PLUGIN FOUND* 📂\n` +
                  `🔍 Command Target: *${text}*\n` +
                  `──────────────────\n\n`;

    found.forEach((item, i) => {
        caption += `📄 *File:* ${item.file}\n` +
                   `⚙️ *Regex:* ${item.cmd}\n` +
                   `──────────────────\n`;
    });

    caption += `\n_Gunakan *${usedPrefix}gp ${found[0].file}* untuk mengambil isinya._`;

    await m.reply(caption);
};

handler.help = ['cpcmd <command>', 'whichplugin <command>'];
handler.tags = ['owner', 'host'];
handler.command = /^(cpcmd|caricommand|whichplugin|cekcmd)$/i;
handler.owner = true;

module.exports = handler;