/*
  FITUR SLOT MAHJONG WAYS (PG SOFT STYLE)
  Konsep: 3x3 Slot Machine
  Simbol: Mahjong Tiles (🀄, 🀅, 🀆, dll)
  Mekanik: Bet Money & Win Multiplier
*/

let handler = async (m, { conn, args, usedPrefix, command }) => {
    let user = global.db.data.users[m.sender];

    // 1. Validasi Database
    if (typeof user.money == 'undefined') user.money = 0;

    // 2. Validasi Input Bet
    let bet = args[0];
    if (!bet) return m.reply(`⚠️ Masukkan jumlah taruhan!\nContoh: *${usedPrefix + command} 10000*`);
    if (isNaN(bet)) return m.reply('⚠️ Jumlah taruhan harus angka!');
    if (bet < 1000) return m.reply('⚠️ Minimal taruhan Rp 1.000');
    if (bet > user.money) return m.reply(`⚠️ Uang kamu tidak cukup!\nSisa uang: Rp ${user.money.toLocaleString()}`);

    bet = parseInt(bet);

    // 3. Definisi Simbol & Multiplier
    // Urutan: [Simbol, Chance(Berat), Multiplier]
    // Makin kecil Chance, makin susah muncul.
    const items = [
        { icon: '🀄', chance: 5, multi: 50 },  // Naga Hijau (Jackpot)
        { icon: '🀅', chance: 10, multi: 20 }, // Naga Merah
        { icon: '🀆', chance: 15, multi: 10 }, // Naga Putih
        { icon: '🀇', chance: 20, multi: 5 },  // Karakter
        { icon: '🀐', chance: 25, multi: 3 },  // Bambu
        { icon: '🀙', chance: 25, multi: 2 },  // Lingkaran
        { icon: '🧧', chance: 5, multi: 100 } // Wild/Scatter (Super Jackpot)
    ];

    // Fungsi pengacak berdasarkan berat (Weighted Random)
    function spin() {
        let totalChance = items.reduce((acc, item) => acc + item.chance, 0);
        let random = Math.random() * totalChance;
        for (let item of items) {
            if (random < item.chance) return item;
            random -= item.chance;
        }
        return items[items.length - 1];
    }

    // 4. Kurangi Uang Awal
    user.money -= bet;

    // 5. Putar Slot (Generate 3x3 Grid)
    let result = [];
    for (let i = 0; i < 3; i++) { // 3 Baris
        let row = [];
        for (let j = 0; j < 3; j++) { // 3 Kolom
            row.push(spin());
        }
        result.push(row);
    }

    // 6. Cek Kemenangan (Hanya Baris Tengah / Index 1)
    let row1 = result[0].map(x => x.icon);
    let row2 = result[1].map(x => x.icon); // Main Payline
    let row3 = result[2].map(x => x.icon);

    let isWin = false;
    let winAmount = 0;
    let multiplier = 0;

    // Logika Menang: 3 Simbol Sama di Baris Tengah
    if (result[1][0].icon === result[1][1].icon && result[1][1].icon === result[1][2].icon) {
        isWin = true;
        multiplier = result[1][0].multi;
        
        // Fitur Gacor: Random Extra Multiplier (x2, x5, x10)
        let extraGacor = [1, 1, 2, 5, 10][Math.floor(Math.random() * 5)];
        multiplier = multiplier * extraGacor;
        
        winAmount = bet * multiplier;
        user.money += winAmount;
    } 
    // Logika Menang Kecil: 2 Simbol Sama (Kiri & Tengah)
    else if (result[1][0].icon === result[1][1].icon) {
        isWin = true;
        multiplier = 1.5; // Balik modal dikit
        winAmount = Math.floor(bet * multiplier);
        user.money += winAmount;
    }

    // 7. Tampilan Visual
    let display = `
🎰 *MAHJONG WAYS 2* 🎰
───────────────
  ${row1.join(' | ')}
> ${row2.join(' | ')} <
  ${row3.join(' | ')}
───────────────
`;

    if (isWin) {
        let caption = `${display}\n` +
                      `🎉 *GACOR KANG!* 🎉\n` +
                      `Win: *x${multiplier}*\n` +
                      `Total: +Rp ${winAmount.toLocaleString()}\n` +
                      `💰 Saldo: Rp ${user.money.toLocaleString()}`;
        
        // Kirim dengan gambar Naga Mahjong
        await conn.sendMessage(m.chat, {
            text: caption,
            contextInfo: {
                externalAdReply: {
                    title: "BIG WIN! MAHJONG WAYS",
                    body: "PG Soft Gacor Parah",
                    thumbnailUrl: "https://telegra.ph/file/a786b4269db88249a4972.jpg", // Gambar Mahjong
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });
    } else {
        let caption = `${display}\n` +
                      `☠️ *RUNGKAD!* ☠️\n` +
                      `Kamu kalah Rp ${bet.toLocaleString()}\n` +
                      `💰 Saldo: Rp ${user.money.toLocaleString()}\n\n` +
                      `_Jangan menyerah, pola gacor selanjutnya menanti!_`;
        
        m.reply(caption);
    }
};

handler.help = ['mahjong <jumlah>', 'slot <jumlah>'];
handler.tags = ['game', 'rpg'];
handler.command = /^(mahjong|slot|mahjongways|pgsoft)$/i;
handler.register = true;
handler.group = true; // Opsional

module.exports = handler;