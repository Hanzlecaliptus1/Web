const fetch = require('node-fetch');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Cek Input
    if (!text) return m.reply(
        `👋 *Woy Bro! Gue Hanz.*\n\n` +
        `Ada yang bisa gue bantu gak? Cerita aja sini.\n` +
        `Contoh: *${usedPrefix + command} Hanz, rekomendasi lagu galau dong*`
    );

    // 2. Efek Mengetik (Biar terlihat seperti manusia)
    await conn.sendPresenceUpdate('composing', m.chat);

    try {
        // 3. KONFIGURASI KEPRIBADIAN (SYSTEM PROMPT)
        // Ini adalah "Otak" yang membuat Hanz jadi gaul.
        let logic = `
            Instruksi Karakter:
            - Nama lo adalah Hanz.
            - Lo adalah asisten virtual cowok yang paling kece, pintar, dan setia kawan.
            - Pencipta lo adalah HanzOfficial.
            - Gaya Bicara: Gunakan bahasa gaul Indonesia (Lo/Gue), santuy, dan akrab.
            - Sifat: Sedikit tengil tapi peduli, humoris, dan suka pakai emoji (😎, 🔥, 🤙, 🤣).
            - Larangan: JANGAN PERNAH bilang "saya adalah model bahasa AI". Anggap lo manusia virtual.
            - Tugas: Jawab pertanyaan user di bawah ini dengan gaya Hanz yang asik.
        `;

        // 4. Request ke API (Gratis & Support Prompt)
        // Menggunakan Widipe GPT Prompt Endpoint
        let apiUrl = `https://widipe.com/prompt/gpt?prompt=${encodeURIComponent(logic)}&text=${encodeURIComponent(text)}`;

        let res = await fetch(apiUrl);
        let json = await res.json();

        // 5. Validasi Jawaban
        if (!json.result) throw "No response from API";

        // 6. Kirim Pesan dengan Tampilan Keren
        await conn.sendMessage(m.chat, {
            text: json.result,
            contextInfo: {
                mentionedJid: [m.sender],
                isForwarded: true,
                forwardingScore: 999,
                externalAdReply: {
                    title: "Hanz Intelligence System",
                    body: "Click here to follow channel",
                    thumbnailUrl: "https://files.catbox.moe/uifi36.jpg", // Ganti Foto Hanz
                    sourceUrl: "https://whatsapp.com/channel/0029Vb6AlYhGzzKTecrl092o", // Ganti Link Channelmu
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply("Waduh, jaringan gue lagi lag nih bro 🤕 Coba tanya lagi nanti ya!");
    }
};

handler.help = ['hanz <teks>', 'tanya <teks>'];
handler.tags = ['ai', 'main'];
handler.command = /^(hanz|botaik|tanya|ngobrol)$/i;
handler.limit = true;

module.exports = handler;