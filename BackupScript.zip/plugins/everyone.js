/**
 * Plugin: everyone-fakereply
 * Description:
 *  Mengirim pesan yang "fake-reply" (membuat quoted message palsu) sambil menyebut semua anggota grup.
 *  Cocok untuk menarik perhatian seluruh grup ketika ingin mengumumkan sesuatu.
 *
 * Usage:
 *  - Reply ke sebuah pesan lalu ketik:
 *      .everyonefakereply <teks tambahan (opsional)>
 *    -> Bot akan mengirim pesan yang membalas (quoted) pesan palsu dari salah satu anggota,
 *       dan menyebut seluruh anggota grup.
 *
 *  - Atau tanpa reply:
 *      .everyonefakereply Pengumuman penting: ...
 *
 * Notes & Safety:
 *  - Hanya dapat dijalankan di group (handler.group = true).
 *  - Membatasi penggunaan hanya untuk admin grup atau owner bot (handler.admin = true, handler.owner = false).
 *    Jika Anda ingin hanya owner yang bisa menjalankan, ubah handler.owner = true.
 *  - Bot akan memilih peserta acak sebagai "pengirim" pada quoted message palsu (bukan dari bot itu sendiri).
 *  - Quoted message palsu menggunakan format sederhana sehingga kompatibel luas.
 */

let handler = async (m, { conn, usedPrefix: _p, command }) => {
  try {
    if (!m.isGroup) return conn.reply(m.chat, 'Perintah ini hanya dapat digunakan di grup.', m)

    // ambil metadata grup
    let metadata = await conn.groupMetadata(m.chat).catch(() => null)
    if (!metadata) return conn.reply(m.chat, 'Gagal mengambil metadata grup.', m)

    // daftar peserta (jid)
    let participants = (metadata.participants || []).map(p => p.id || p.jid || p)
    // pastikan ada peserta
    if (!participants || participants.length === 0) return conn.reply(m.chat, 'Tidak ada anggota grup ditemukan.', m)

    // keluarkan jid bot sendiri dari daftar calon "fake sender"
    const botJid = (conn.user && conn.user.id) ? conn.user.id : (conn.user && conn.user.jid) ? conn.user.jid : null
    let candidates = participants.filter(jid => jid && jid !== botJid)

    // jika tidak ada kandidat (mis. bot satu-satunya), gunakan first participant
    if (candidates.length === 0) candidates = participants.slice(0, 1)

    // ambil teks yang akan dikirim
    // jika user membalas sebuah pesan, gunakan teks dari reply sebagai konten quoted asli (jika tersedia)
    let quotedSourceText = ''
    try {
      if (m.quoted) {
        // beberapa struktur pesan: m.quoted.text atau m.quoted.message.conversation
        quotedSourceText = m.quoted.text ||
                           (m.quoted.message && (m.quoted.message.conversation || m.quoted.message.extendedTextMessage && m.quoted.message.extendedTextMessage.text)) ||
                           ''
      }
    } catch (e) {
      quotedSourceText = ''
    }

    // teks akhir yang dikirim sebagai pesan bot (bisa berisi teks tambahan dari perintah)
    // Perintah contoh: .everyonefakereply Pengumuman penting...
    let argsText = (m.text || '').trim().split(/\s+/).slice(1).join(' ').trim() // hapus command
    let messageText = argsText || quotedSourceText || 'Halo semuanya 👋'

    // buat objek quoted palsu: akan terlihat seperti membalas pesan dari participantRandom
    const participantRandom = candidates[Math.floor(Math.random() * candidates.length)]
    // buat id unik untuk quoted fake
    const fakeId = 'FAKE_REPLY_' + Date.now()

    // bentuk message.simple conversation (kompatibel), gunakan extendedTextMessage bila perlu
    const fakeQuoted = {
      key: {
        remoteJid: m.chat,
        fromMe: false,
        id: fakeId,
        participant: participantRandom
      },
      message: {
        conversation: quotedSourceText || `Pesan oleh ${participantRandom.split('@')[0]}`
      }
    }

    // mention semua anggota
    const mentions = participants

    // kirim pesan: menggunakan option quoted untuk membuat seakan-akan membalas fakeQuoted
    await conn.sendMessage(m.chat, { text: messageText }, { quoted: fakeQuoted, mentions })

    // konfirmasi singkat
    return conn.reply(m.chat, `✅ Mengirim fakereply dan menandai ${participants.length} anggota.`, m)
  } catch (err) {
    console.error(err)
    return conn.reply(m.chat, 'Terjadi kesalahan saat menjalankan everyone-fakereply.', m)
  }
}

handler.help = ['everyonefakereply']
handler.tags = ['group', 'owner']
handler.command = /^everyonefakereply$/i
handler.group = true
handler.admin = true // hanya admin grup yang dapat menjalankan; ubah sesuai kebutuhan
handler.owner = false
handler.mods = false
handler.premium = false
handler.private = false
handler.limit = false
handler.exp = 0

module.exports = handler