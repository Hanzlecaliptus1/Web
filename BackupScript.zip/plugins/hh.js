const { generateWAMessageFromContent } = require('@adiwajshing/baileys')

let handler = async (m, { conn, text, usedPrefix, command, participants, isGroup }) => {
    // 1. Ambil konten (Text atau Media)
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''
    text = text || (q.text || q.caption || q.description || '')

    // 2. Validasi input
    if (!text && !mime) {
        return conn.reply(m.chat, `⚠️ *Format Salah!*\n\nGunakan: ${usedPrefix + command} <teks>\nAtau reply media dengan caption.`, m)
    }

    // 3. Beri Reaksi bahwa bot sedang bekerja
    await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } })

    // 4. Ambil Data Grup & Member
    const groupMetadata = isGroup ? await conn.groupMetadata(m.chat) : ""
    const groupName = groupMetadata ? groupMetadata.subject : "Shiroko Broadcast"
    let users = participants.map(u => u.id)

    // 5. Konfigurasi Tampilan "Keren" (Context Info)
    const contextInfo = {
        mentionedJid: users, // Tag semua member
        forwardingScore: 999,
        isForwarded: true,
        externalAdReply: {
            title: "🔊 𝙎𝙝𝙞𝙧𝙤𝙠𝙤 𝘼𝙣𝙣𝙤𝙪𝙣𝙘𝙚𝙢𝙚𝙣𝙩",
            body: `Group: ${groupName}`,
            // Ganti URL ini dengan link gambar Shiroko/Bot kamu
            thumbnailUrl: 'https://files.catbox.moe/rx688r.jpg', 
            sourceUrl: '', // Bisa diisi link grup atau kosongkan
            mediaType: 1,
            renderLargerThumbnail: true // Membuat thumbnail jadi besar (Banner)
        }
    }

    // 6. Konfigurasi Fake Reply (Tampilan Reply di bawah banner)
    const fakereply = {
        key: {
            participants: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            fromMe: false,
            id: "Broadcast"
        },
        message: {
            conversation: `⚡ 𝘽𝙧𝙤𝙖𝙙𝙘𝙖𝙨𝙩 𝙗𝙮 𝙎𝙝𝙞𝙧𝙤𝙠𝙤`
        },
        participant: "0@s.whatsapp.net"
    }

    // 7. Logika Pengiriman
    if (/image|video|audio/.test(mime)) {
        let media = await q.download?.()
        if (!media) throw 'Gagal mengunduh media.'

        let msgOptions = {
            [mime.includes('image') ? 'image' : mime.includes('video') ? 'video' : 'audio']: media,
            caption: mime.includes('audio') ? undefined : text,
            contextInfo: contextInfo // Masukkan style keren di sini
        }

        if (mime.includes('audio')) {
            msgOptions.mimetype = 'audio/mpeg'
            msgOptions.ptt = true 
        }

        await conn.sendMessage(m.chat, msgOptions, { quoted: fakereply })
        
    } else if (/sticker/.test(mime)) {
        let media = await q.download?.()
        if (!media) throw 'Gagal mengunduh sticker.'
        
        await conn.sendMessage(m.chat, { 
            sticker: media, 
            contextInfo: contextInfo
        }, { quoted: fakereply })

    } else {
        // Kirim Teks Biasa dengan Style
        await conn.sendMessage(m.chat, { 
            text: text, 
            contextInfo: contextInfo
        }, { quoted: fakereply })
    }
}

handler.help = ['hidetag <teks>']
handler.tags = ['group']
handler.command = /^(hidetag|ht|hh|everyone)$/i

handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler