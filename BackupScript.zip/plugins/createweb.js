const axios = require('axios');

// --- KONFIGURASI ---
// Ganti dengan Token Vercel Anda. 
// SANGAT DISARANKAN taruh ini di config.js atau .env agar aman.
const VERCEL_TOKEN = 'AmZ2LzY9V7Pek0AnSTP9oarP'; 

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    // 1. Cek Input User
    // Format: .createweb namaproject|kodehtml
    if (!text) {
      return m.reply(`
⚠️ *Format Salah!*

Gunakan format:
*${usedPrefix + command} nama-project|kode-html*

Contoh:
*${usedPrefix + command} hanz-bio|<h1>Halo, ini Hanz</h1>*

Atau cukup nama project untuk template default:
*${usedPrefix + command} hanz-store*
      `.trim());
    }

    // 2. Parsing Data (Nama Project & HTML)
    let [projectName, htmlContent] = text.split('|');
    
    // Bersihkan nama project (hanya boleh huruf kecil, angka, dan dash)
    projectName = projectName.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');

    if (projectName.length < 3) return m.reply('❌ Nama project minimal 3 karakter!');

    // Jika user tidak mengisi HTML, gunakan Template Keren Default
    if (!htmlContent) {
      htmlContent = getDefaultTemplate(projectName);
    }

    await m.reply('🚀 *Sedang mendeploy ke server Vercel...*\nMohon tunggu sekitar 10-30 detik.');

    // 3. Request ke Vercel API
    const response = await axios.post('https://api.vercel.com/v13/deployments', {
      name: projectName, // Nama Project di Dashboard Vercel
      files: [
        {
          file: 'index.html',
          data: htmlContent // Isi file HTML
        }
      ],
      projectSettings: {
        framework: null // Static HTML
      },
      target: 'production' // Langsung deploy ke production
    }, {
      headers: {
        'Authorization': `Bearer ${VERCEL_TOKEN}`,
        'Content-Type': 'application/json'
      }
    });

    // 4. Sukses
    const result = response.data;
    const deployUrl = result.alias?.[0] || result.url; // Ambil URL hasil deploy
    
    // Kirim pesan sukses
    const successMsg = `
✅ *WEBSITE BERHASIL DIBUAT!*

📂 *Project:* ${result.name}
🔗 *URL:* https://${deployUrl}
📅 *Created:* ${new Date().toLocaleString()}

_Website sudah online dan bisa diakses seluruh dunia!_
    `.trim();

    await conn.sendMessage(m.chat, { text: successMsg }, { quoted: m });

  } catch (e) {
    console.error(e);
    // Handling Error Vercel yang umum
    if (e.response) {
      const errorData = e.response.data;
      if (errorData.error && errorData.error.code === 'forbidden') {
        return m.reply('❌ *Akses Ditolak!* Token Vercel salah atau expired.');
      }
      if (errorData.error && errorData.error.code === 'missing_project_settings') {
        return m.reply('❌ Nama project sudah ada milik orang lain atau tidak valid. Coba nama lain!');
      }
      return m.reply(`❌ *Gagal Deploy:*\n${JSON.stringify(errorData.error.message)}`);
    }
    m.reply('❌ Terjadi kesalahan internal.');
  }
};

handler.help = ['createweb'];
handler.command = /^(createweb|deployweb)$/i;
handler.tags = ['tools', 'internet'];

module.exports = handler;

// --- TEMPLATE HTML DEFAULT (JIKA USER KOSONG) ---
function getDefaultTemplate(name) {
  return `
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${name.toUpperCase()}</title>
    <style>
        body {
            background-color: #000;
            color: #0f0;
            font-family: 'Courier New', Courier, monospace;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        h1 { font-size: 3rem; text-shadow: 0 0 10px #0f0; }
        p { font-size: 1.2rem; }
        .box {
            border: 2px solid #0f0;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px #0f0;
        }
        .btn {
            margin-top: 20px;
            padding: 10px 20px;
            background: #0f0;
            color: #000;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="box">
        <h1>${name.toUpperCase()}</h1>
        <p>Website ini berhasil dibuat melalui WhatsApp Bot.</p>
        <p>Status: <span style="color: yellow;">ONLINE</span></p>
        <br>
        <a href="#" class="btn">Hubungi Owner</a>
    </div>
</body>
</html>
  `;
}