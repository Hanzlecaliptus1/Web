let fetch = require("node-fetch")

let handler = async (m, { conn, command }) => {
  try {
    let who
    
    // --- LOGIKA TARGET (GROUP VS PRIVATE) ---
    if (m.isGroup) {
        // Di Group: Prioritas Mention -> Reply -> Diri Sendiri
        who = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : m.sender)
    } else {
        // Di Private: Prioritas Reply -> Diri Sendiri (Lawan bicara/Kamu)
        who = m.quoted ? m.quoted.sender : m.sender
    }

    // --- AMBIL URL FOTO ---
    // Menggunakan catch di sini agar jika tidak ada PP, langsung lari ke gambar default
    let pp = await conn.profilePictureUrl(who, 'image').catch((_) => "https://telegra.ph/file/24fa902ead26340f3df2c.png")
    
    // --- BUAT THUMBNAIL BUFFER ---
    let buffer = await (await fetch(pp)).buffer()

    // --- KIRIM ---
    await conn.sendFile(m.chat, pp, 'pp.jpg', 'Nih kak profilnya.', m, { jpegThumbnail: buffer })

  } catch (e) {
    // Fallback error handling
    console.error(e)
    m.reply("Gagal mengambil foto profil.")
  }
}

handler.help = ['getpp <@tag/reply>']
handler.tags = ['tools']
handler.command = /^(getpp|ava|avatar)$/i

// handler.group = true  <-- INI DIHAPUS AGAR BISA DI PRIVATE CHAT
handler.limit = true

module.exports = handler