const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Validasi Input
    if (!text) return m.reply(`❌ *Linknya mana?*\nContoh: ${usedPrefix + command} https://pin.it/xyz...`);
    if (!text.includes('pinterest') && !text.includes('pin.it')) return m.reply('❌ Link tidak valid! Harap kirim link Pinterest.');

    // 2. Setup Fake Reply (Tema Pinterest Aesthetic)
    let fakePin = {
        key: { 
            fromMe: false, 
            participant: `0@s.whatsapp.net`, 
            remoteJid: 'status@broadcast' 
        },
        message: {
            extendedTextMessage: {
                text: `Pinterest Downloader`, // Text kecil preview
                contextInfo: {
                    externalAdReply: {
                        title: '📌 PINTEREST SAVER',
                        body: 'Downloading High Quality Media...',
                        thumbnailUrl: 'https://i.pinimg.com/736x/8f/3e/26/8f3e26456cd7895e634cb246d845de50.jpg', // Logo Pinterest Aesthetic
                        sourceUrl: text, // Link asli postingan
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }
        }
    }

    // 3. Notifikasi Loading
    m.reply('🔍 *Sedang mencari media...*');

    try {
        // 4. Request ke API
        // Menggunakan API Agatz yang support pin.it (short url) dan pinterest.com (long url)
        let { data } = await axios.get(`https://api.agatz.xyz/api/pinterest?url=${encodeURIComponent(text)}`);

        // Cek status API
        if (!data || !data.data || !data.data.result) {
            throw 'Media tidak ditemukan atau link private.';
        }

        let resultUrl = data.data.result;
        let fileType = resultUrl.includes('.mp4') ? 'video' : 'image';

        // 5. Kirim Media
        if (fileType === 'video') {
            await conn.sendMessage(m.chat, { 
                video: { url: resultUrl }, 
                caption: `✅ *Download Success*\n🔗 Link: ${text}\n🤖 By: HanzOffc`
            }, { quoted: fakePin });
        } else {
            await conn.sendMessage(m.chat, { 
                image: { url: resultUrl }, 
                caption: `✅ *Download Success*\n🔗 Link: ${text}\n🤖 By: HanzOffc`
            }, { quoted: fakePin });
        }

    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal mendownload. Pastikan link tidak private atau coba lagi nanti.');
    }
}

handler.help = ['pindl <link>', 'pinvid <link>'];
handler.tags = ['downloader'];
handler.command = /^(pindl|pinvid|pinterestdl)$/i;
handler.limit = true;

module.exports = handler;