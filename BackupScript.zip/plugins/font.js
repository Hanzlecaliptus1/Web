/**
 * plugins/font-style.js
 *
 * Fitur: style font
 * Perintah:
 *   .font <style> <teks>
 *   .font <style> (reply ke pesan)    -> gunakan teks dari pesan yang direply
 *   .font (tanpa arg)                 -> menampilkan daftar style dan contoh
 *
 * Contoh:
 *   .font full Hello World
 *   .font circled Ini contoh
 *   (reply ke pesan) .font upsidedown
 *
 * Style yang tersedia:
 *   - full        : Fullwidth (ＡＢＣ)
 *   - circled     : Huruf dalam lingkaran (ⒶⒷⒸ)
 *   - upsidedown  : Terbalik (ʍoɹlp)
 *   - reverse     : Dibalik teks (dlroW olleH)
 *   - spaced      : Spasi antar huruf (H e l l o)
 *   - mock        : aLtErNaTe CaPs (mEmE style)
 *   - smallcaps   : Huruf small-caps (ᴀʙᴄ) - sebagian huruf fallback ke uppercase
 *
 * Batasan:
 *   - Panjang teks dibatasi (DEFAULT_MAX = 800) untuk mencegah pesan sangat besar.
 *   - Dapat digunakan di private maupun group.
 */

const DEFAULT_MAX = 800

const styles = {
  // fullwidth: ASCII 33-126 mapped to fullwidth block (offset 65248). Space remains space.
  full: txt => {
    return txt.split('').map(ch => {
      const code = ch.charCodeAt(0)
      if (code >= 33 && code <= 126) return String.fromCharCode(code + 65248)
      if (ch === ' ') return ' '
      return ch
    }).join('')
  },

  // circled: a-z -> ⓐ.., A-Z -> Ⓐ..
  circled: txt => {
    return txt.split('').map(ch => {
      if (ch >= 'a' && ch <= 'z') return String.fromCharCode(0x24D0 + (ch.charCodeAt(0) - 97))
      if (ch >= 'A' && ch <= 'Z') return String.fromCharCode(0x24B6 + (ch.charCodeAt(0) - 65))
      if (ch >= '0' && ch <= '9') {
        // circled numbers 0..9 are at 0x2460 for 1..10; fallback to itself
        const map = { '0': '0', '1': '\u2460', '2': '\u2461', '3': '\u2462', '4': '\u2463', '5': '\u2464', '6': '\u2465', '7': '\u2466', '8': '\u2467', '9': '\u2468' }
        return map[ch] || ch
      }
      return ch
    }).join('')
  },

  // upsidedown: map chars to upside-down equivalents then reverse string
  upsidedown: txt => {
    const map = {
      a: 'ɐ', b: 'q', c: 'ɔ', d: 'p', e: 'ǝ', f: 'ɟ', g: 'ƃ', h: 'ɥ', i: 'ᴉ', j: 'ɾ',
      k: 'ʞ', l: 'l', m: 'ɯ', n: 'u', o: 'o', p: 'd', q: 'b', r: 'ɹ', s: 's', t: 'ʇ',
      u: 'n', v: 'ʌ', w: 'ʍ', x: 'x', y: 'ʎ', z: 'z',
      A: '∀', B: 'ᗺ', C: 'Ↄ', D: '◖', E: 'Ǝ', F: 'Ⅎ', G: 'פ', H: 'H', I: 'I', J: 'ſ',
      K: '⋊', L: '˥', M: 'W', N: 'N', O: 'O', P: 'Ԁ', Q: 'Ό', R: 'ᴚ', S: 'S', T: '⊥',
      U: '∩', V: 'Λ', W: 'M', X: 'X', Y: '⅄', Z: 'Z',
      '1': 'Ɩ', '2': 'ᘔ', '3': 'Ɛ', '4': '߈', '5': 'ϛ', '6': '9', '7': 'ㄥ', '8': '8', '9': '6', '0': '0',
      '.': '˙', ',': "'", "'": ',', '"': '„', '?': '¿', '!': '¡', '[': ']', ']': '[', '(': ')', ')': '(',
      '{': '}', '}': '{', '<': '>', '>': '<', '_': '‾', '&': '⅋', ':': ':', ';': '؛'
    }
    const transformed = txt.split('').map(ch => map[ch] !== undefined ? map[ch] : (map[ch.toLowerCase()] || ch))
    return transformed.reverse().join('')
  },

  // reverse: balik urutan karakter
  reverse: txt => txt.split('').reverse().join(''),

  // spaced: tambahkan spasi antar karakter non-space
  spaced: txt => txt.split('').map(ch => ch === ' ' ? ' ' : ch + ' ').join('').trim(),

  // mock: alternating caps starting with lowercase (mOcK)
  mock: txt => {
    let up = false
    return txt.split('').map(ch => {
      if (/[a-zA-Z]/.test(ch)) {
        up = !up
        return up ? ch.toUpperCase() : ch.toLowerCase()
      } else return ch
    }).join('')
  },

  // smallcaps: map sebagian huruf ke small-cap Unicode, fallback ke uppercase jika tidak ada mapping
  smallcaps: txt => {
    const map = {
      a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ', i: 'ɪ', j: 'ᴊ',
      k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ', s: 's', t: 'ᴛ',
      u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
    }
    return txt.split('').map(ch => {
      const lower = ch.toLowerCase()
      if (map[lower]) return map[lower]
      if (/[A-Z]/.test(ch)) return ch // keep uppercase as-is
      return ch
    }).join('')
  }
}

let handler = async (m, { conn, usedPrefix: _p, args }) => {
  try {
    // ambil teks dari argumen atau dari reply
    const input = (args || []).slice(1).join(' ').trim() // jika args[0] adalah style
    const style = (args && args[0]) ? args[0].toLowerCase() : ''
    let text = input

    if (!text) {
      // coba ambil dari reply
      try {
        if (m.quoted && (m.quoted.text || (m.quoted.message && m.quoted.message.conversation))) {
          text = m.quoted.text || m.quoted.message.conversation || ''
        }
      } catch (e) {
        text = ''
      }
    }

    // jika tidak ada style -> tampilkan daftar
    if (!style) {
      const list = Object.keys(styles).map(k => `• ${k}`).join('\n')
      const examples = Object.entries(styles).slice(0, 6).map(([k, fn]) => {
        const ex = fn('Contoh')
        return `${k}: ${ex}`
      }).join('\n')
      return conn.reply(m.chat,
        `Fitur style font\n\nGunakan: ${_p}font <style> <teks>\nContoh: ${_p}font full Hello World\n\nStyle tersedia:\n${list}\n\nContoh singkat:\n${examples}\n\nCatatan: Kamu juga bisa reply pesan lalu ketik ${_p}font <style>`,
        m)
    }

    if (!styles[style]) {
      return conn.reply(m.chat, `Style "${style}" tidak ditemukan. Ketik ${_p}font untuk melihat daftar style.`, m)
    }

    if (!text) return conn.reply(m.chat, `Silakan sertakan teks atau reply ke pesan untuk dijadikan input.\nContoh: ${_p}font ${style} Halo`, m)

    if (text.length > DEFAULT_MAX) return conn.reply(m.chat, `Teks terlalu panjang. Maksimal ${DEFAULT_MAX} karakter.`, m)

    // transform
    const result = styles[style](text)

    // kirim hasil
    await conn.reply(m.chat, result, m)
  } catch (err) {
    console.error(err)
    conn.reply(m.chat, 'Terjadi error saat memproses style font.', m)
  }
}

handler.help = ['font <style> <teks>', 'font <style> (reply)']
handler.tags = ['tools', 'fun']
handler.command = /^(font|style|fontstyle|stylefont)$/i
handler.group = false
handler.botAdmin = false
handler.admin = false
handler.owner = false
handler.mods = false
handler.premium = false
handler.private = false
handler.limit = 2
handler.exp = 0

module.exports = handler