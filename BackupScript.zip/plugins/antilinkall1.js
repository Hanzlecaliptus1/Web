/*
  FITUR ANTI LINK ALL (DELETE ONLY)
  Fungsi: Menghapus semua pesan yang mengandung Link (HTTP/HTTPS/WWW).
  Tindakan: Hapus Pesan + Peringatan (Tanpa Kick).
*/

let handler = m => m;

// handler.before berjalan otomatis mendeteksi setiap pesan masuk
handler.before = async function (m, { conn, isAdmin, isBotAdmin }) {
    // 1. Cek Kondisi Dasar
    if (!m.isGroup || m.isBaileys) return true; // Hanya di grup & bukan pesan bot sendiri
    if (isAdmin || m.isOwner) return true;     // Admin & Owner bebas kirim link

    // 2. Cek Database Chat
    let chat = global.db.data.chats[m.chat];
    
    // Jika fitur belum dinyalakan, skip
    if (!chat || !chat.antiLinkAll) return true;

    // 3. Regex Pendeteksi Link (Semua Link)
    // Mendeteksi http://, https://, www., dan wa.me
    let linkRegex = /(https?:\/\/|www\.|wa\.me\/|t\.me\/)/i;
    
    // Cek apakah pesan mengandung link?
    if (linkRegex.test(m.text)) {
        
        // 4. Cek Apakah Bot Admin?
        if (!isBotAdmin) {
            // Jika bot bukan admin, tidak bisa hapus pesan
            // console.log('Bot bukan admin, tidak bisa hapus link.');
            return true; 
        }

        // 5. Eksekusi Hapus Pesan
        await conn.sendMessage(m.chat, { delete: m.key });

        // 6. Kirim Peringatan (Opsional)
        // Bot akan mentag orang tersebut
        await conn.sendMessage(m.chat, { 
            text: `⚠️ *LINK TERDETEKSI* ⚠️\n\nMaaf @${m.sender.split("@")[0]}, dilarang mengirim link apapun di grup ini.`,
            mentions: [m.sender]
        });
        
        return false; // Stop proses agar command lain tidak berjalan
    }

    return true;
};

module.exports = handler;