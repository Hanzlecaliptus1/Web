/*
  FITUR KATA-KATA HANZ (CommonJS)
  Fungsi: Mengirim random quotes tanpa API Key eksternal.
  Database: Lokal Array
*/

let handler = async (m, { conn }) => {
    // KUMPULAN KATA-KATA PILIHAN (Bisa ditambah sendiri)
    const quotes = [
        "Hidup bukan tentang menunggu badai berlalu, tapi tentang belajar menari di tengah hujan.",
        "Jangan takut berjalan lambat, takutlah jika hanya berdiri diam.",
        "Kegagalan adalah bumbu kehidupan yang membuat kesuksesan terasa lebih nikmat.",
        "Seberat apapun masalahmu, jangan lupa makan. Pura-pura bahagia itu butuh tenaga.",
        "Bukan siapa yang memujimu di hadapanmu, tapi siapa yang menjagamu di belakangmu.",
        "Hanz bilang: 'Kalau mimpimu belum ditertawakan orang lain, berarti mimpimu masih terlalu kecil.'",
        "Jangan menjelaskan tentang dirimu kepada siapapun, karena yang menyukaimu tidak butuh itu, dan yang membencimu tidak percaya itu.",
        "Terkadang kita terlalu sibuk memikirkan pintu yang tertutup, hingga tidak sadar ada pintu lain yang terbuka.",
        "Sabar itu ilmu tingkat tinggi. Belajarnya setiap hari, latihannya setiap saat, ujiannya sering mendadak.",
        "Jangan bandingkan prosesmu dengan orang lain. Bunga tidak mekar secara bersamaan.",
        "Kalau capek istirahat, bukan berhenti. Ingat, cicilan dan impian masih menumpuk.",
        "Hanz mengingatkan: 'Dunia tidak akan kiamat hanya karena kamu kehilangan satu orang yang tidak menghargaimu.'",
        "Lebih baik dibenci karena menjadi diri sendiri, daripada disukai tapi berpura-pura menjadi orang lain.",
        "Uang bisa dicari, muka bisa dioperasi, tapi isi hati siapa yang tahu?",
        "Jadilah seperti kopi, yang tetap dicintai tanpa menyembunyikan pahitnya diri.",
        "Sukses itu seperti hamil. Semua orang memberi selamat, tapi tidak ada yang tahu berapa kali dia 'dientot' oleh kehidupan.",
        "Waktu adalah uang, tapi uang tidak bisa membeli waktu. Hargai setiap detiknya.",
        "Jangan menuntut Tuhan untuk menepati janji-Nya, jika kamu sendiri sering ingkar pada-Nya.",
        "Tetaplah bersinar meskipun duniamu sedang gelap.",
        "Hanz be like: 'Chat gak dibales? Positif thinking aja, mungkin dia lagi sibuk... sibuk sayang sama yang lain.'",
        "Langit tidak perlu menjelaskan bahwa dirinya tinggi. Orang tidak perlu menjelaskan bahwa dirinya baik.",
        "Balas dendam terbaik adalah menjadikan dirimu lebih baik.",
        "Jangan lupa bersyukur, karena hari ini kita masih diberi napas gratis."
    ];

    // Logika Random Picker
    let randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    
    // Variabel hiasan
    let name = m.pushName || "Kak";

    // Kirim Pesan
    // Menggunakan style reply sederhana tapi rapi
    let caption = `👋 Halo ${name},\n\n📜 *Kata-kata hari ini:*\n\n_"${randomQuote}"_\n\n- Hanz Bot`;

    await m.reply(caption);
};

handler.help = ['hanz'];
handler.tags = ['quotes', 'fun'];
// Command bisa dipanggil dengan: hanz, katakata, atau quotes
handler.command = /^(hanz|katakata|quotes|kata)$/i;

module.exports = handler;