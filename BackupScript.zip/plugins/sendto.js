/*
  FITUR KIRIM TEKS KE ORANG LAIN (CommonJS)
  Fungsi: Mengirim pesan teks ke nomor WhatsApp tertentu via Bot.
  Akses: Khusus Owner.
*/

let handler = async (m, { conn, text, args, isOwner, usedPrefix, command }) => {
    // 1. Validasi Owner
    if (!isOwner) return m.reply('❌ *AKSES DITOLAK*\nFitur ini hanya untuk Owner Bot!');
    
    // 2. Validasi Input
    if (args.length < 2) {
        return m.reply(
            `⚠️ *FORMAT SALAH*\n\n` +
            `Gunakan: *${usedPrefix + command} <nomor_tujuan> <pesan>*\n\n` +
            `Contoh:\n*${usedPrefix + command}* 62857xxxxxx Halo ini pesan test.`
        );
    }

    let targetNumber = args[0];
    let message = args.slice(1).join(' ').trim();

    if (!message) return m.reply('Pesan yang mau dikirim kosong.');

    // 3. Format Nomor ke JID
    let targetJid = formatJid(targetNumber);

    // Final Check JID Validity
    if (!targetJid.includes('@s.whatsapp.net') || targetJid.length < 15) {
        return m.reply('❌ Format nomor tujuan salah. Pastikan diawali 62 dan bukan grup.');
    }

    try {
        m.reply(`⏳ Mengirim pesan ke ${targetNumber}...`);
        
        // 4. Send the message
        await conn.sendMessage(targetJid, { text: message });

        // 5. Konfirmasi ke Owner
        m.reply(`✅ Pesan berhasil dikirim ke *${targetNumber}*.`);

    } catch (e) {
        console.error(e);
        m.reply(`❌ Gagal mengirim pesan ke ${targetNumber}.`);
    }
};

handler.help = ['sendto <nomor> <pesan>'];
handler.tags = ['owner'];
handler.command = /^(sendto|kirimto|kirimpesan)$/i;
handler.owner = true;

module.exports = handler;

// --- FUNGSI HELPER: FORMAT NOMOR KE JID ---
function formatJid(num) {
    // Menghilangkan karakter non-angka/non-@
    num = num.replace(/[^0-9]/g, ''); 
    
    // Konversi 08xxx atau +628xxx menjadi 628xxx
    if (num.startsWith('08')) num = '62' + num.slice(1);
    if (num.startsWith('+62')) num = num.slice(1);
    
    // Tambahkan domain JID
    if (!num.endsWith('@s.whatsapp.net')) num = num + '@s.whatsapp.net';
    
    return num;
}