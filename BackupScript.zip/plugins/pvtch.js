/* KODE CREATE BY AI
KONVERSI KE COMMONJS
*/

let handler = async (m, { conn }) => {
  let vid;

  // Cek apakah pesan adalah quote video
  if (m.quoted && m.quoted.mtype === "videoMessage") {
    vid = await m.quoted.download();
  }
  // Cek apakah pesan adalah video langsung
  else if (m.mtype === "videoMessage") {
    vid = await m.download();
  }

  // Jika tidak ada video
  if (!vid) {
    throw `Kirim *video* atau *balas video* lalu ketik:\n\n.ptvch`;
  }

  const channelId = "120363400444882911@newsletter"; // GANTI DENGAN ID CHANNELMU

  await conn.sendMessage(
    channelId,
    {
      video: vid,
      mimetype: "video/mp4",
      gifPlayback: true,
      ptv: true,
    }
    // TIDAK boleh ada quoted saat kirim ke channel
  );

  m.reply("✓ Video berhasil dikirim ke channel sebagai PTV!");
};

handler.help = ["ptvch"];
handler.tags = ["owner"];
handler.command = /^ptvch$/i;
handler.owner = true;

module.exports = handler;