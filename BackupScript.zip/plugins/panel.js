let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        // ==========================================
        // 1. KONFIGURASI GAMBAR & THUMBNAIL
        // ==========================================
        // Ganti link ini dengan gambar jualanmu sendiri (harus link gambar langsung/direct link)
        let thumbSewa = 'https://files.catbox.moe/uifi36.jpg'  // Gambar untuk Menu Sewa
        let thumbPanel = 'https://files.catbox.moe/c466te.jpg' // Gambar untuk Menu Panel

        // ==========================================
        // 2. DAFTAR HARGA (EDIT DISINI)
        // ==========================================
        
        // --- TEXT HARGA SEWA BOT ---
        let textSewa = `
┏━━━ *PRICE LIST SEWA BOT* ━━━
┃
┃ 🟢 *PAKET HEMAT*
┃ ├ Rp 5.000 / Minggu
┃ ├ Masa Aktif: 7 Hari
┃ └ Fitur: Antilink + Welcome
┃
┃ 🔵 *PAKET REGULER*
┃ ├ Rp 10.000 / Bulan
┃ ├ Masa Aktif: 30 Hari
┃ └ Fitur: Full Fitur + 24 Jam On
┃
┃ 🟡 *PAKET SULTAN (VIP)*
┃ ├ Rp 25.000 / Permanen
┃ ├ Masa Aktif: Selamanya
┃ └ Fitur: Prioritas + Jadi Owner Bot
┃
┗━━━━━━━━━━━━━━━━━━━━
💳 *Pembayaran:* DANA / GOPAY / QRIS
📞 *Minat?* Hubungi Owner: .owner
`

        // --- TEXT HARGA PANEL PTERO ---
        let textPanel = `
┏━━━ *SHOP PANEL PTERODACTYL* ━━━
┃ 🖥️ *Spesifikasi Server:*
┃ • CPU: Intel Xeon / Ryzen (Random)
┃ • RAM: High Performance
┃ • Uptime: 99% (Anti Mati)
┃
┃ 📦 *DAFTAR HARGA:*
┃ ☁️ 1GB  : Rp 1.000
┃ ☁️ 2GB  : Rp 2.000
┃ ☁️ 3GB  : Rp 3.000
┃ ☁️ 4GB  : Rp 4.000
┃ ☁️ 5GB  : Rp 5.000
┃ ☁️ 8GB  : Rp 8.000
┃ ☁️ UNLI : Rp 15.000
┃
┃ 🎁 *Benefit:*
┃ ✅ Bisa buat Bot WA/Telegram
┃ ✅ Bisa Create Database
┃ ✅ Garansi 1x (S&K Berlaku)
┗━━━━━━━━━━━━━━━━━━━━
💳 *Pembayaran:* DANA / GOPAY / QRIS
📞 *Minat?* Hubungi Owner: .owner
`

        // ==========================================
        // 3. LOGIKA PENGIRIMAN
        // ==========================================

        if (command === 'sewa' || command === 'sewabot') {
            // KIRIM MENU SEWA
            await conn.sendMessage(m.chat, {
                image: { url: thumbSewa },
                caption: textSewa,
                contextInfo: {
                    externalAdReply: {
                        title: "OPEN SEWA BOT GRUP",
                        body: "Jadikan Grupmu Lebih Hidup!",
                        thumbnailUrl: thumbSewa, // Thumbnail kecil di atas
                        sourceUrl: "https://chat.whatsapp.com/...", // Link Grup/Saluran kamu
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m })

        } else if (command === 'panel' || command === 'listpanel' || command === 'shoppanel') {
            // KIRIM MENU PANEL
            await conn.sendMessage(m.chat, {
                image: { url: thumbPanel },
                caption: textPanel,
                contextInfo: {
                    externalAdReply: {
                        title: "HANZ PANEL STORE",
                        body: "Server Kencang & Murah",
                        thumbnailUrl: thumbPanel, // Thumbnail kecil di atas
                        sourceUrl: "https://panel.hanzoffc.com", // Link Panel (Bebas/Opsional)
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m })
        }

    } catch (e) {
        console.error(e)
        m.reply('❌ Terjadi kesalahan saat memuat gambar menu.')
    }
}

// Metadata Plugin
handler.help = ['sewa', 'panel']
handler.tags = ['store', 'main']
handler.command = /^(sewa|sewabot|panel|listpanel|shoppanel)$/i

module.exports = handler