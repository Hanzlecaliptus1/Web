/*
  FITUR UPLOAD TO CHANNEL WITH BUTTON (CommonJS)
  Fungsi: Mengirim media (Foto/Video) + Caption + Button Link ke Channel.
  
  Created by AI
*/

const { 
    generateWAMessageFromContent, 
    proto, 
    prepareWAMessageMedia 
} = require('@adiwajshing/baileys');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Konfigurasi Channel & Button (EDIT DI SINI)
    const config = {
        channelJid: "120363417446780608@newsletter", // GANTI ID CHANNELMU
        buttonText: "Lihat Saluran",                  // Teks pada tombol
        buttonUrl: "https://whatsapp.com/channel/0029Vb5SIlUBlHpfnTE0EG35", // Link tujuan
        footer: "© Hanz Bot Broadcast"               // Teks kecil di bawah
    };

    // 2. Cek Input Media
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!mime) return m.reply(`⚠️ Kirim/Reply foto atau video dengan caption:\n*${usedPrefix + command}* <caption pesan>`);
    if (!text && !m.quoted?.text) return m.reply(`⚠️ Masukkan caption pesannya!`);

    let caption = text || m.quoted.text;

    m.reply('⏳ Mengupload media ke channel...');

    try {
        // 3. Download Media
        let mediaBuffer = await q.download();
        let mediaType = mime.includes('video') ? 'video' : 'image';

        // 4. Siapkan Media untuk Header Pesan
        // Fungsi ini mengupload media ke server WA dan membuat object pesan media
        let mediaMessage = await prepareWAMessageMedia(
            { [mediaType]: mediaBuffer }, 
            { upload: conn.waUploadToServer }
        );

        // 5. Susun Pesan Interaktif (Header Media + Body + Button)
        let msg = generateWAMessageFromContent(config.channelJid, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        // HEADER: Bagian Media (Gambar/Video)
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "", // Title kosong karena pakai media
                            subtitle: "",
                            hasMediaAttachment: true,
                            ...mediaMessage // Masukkan object gambar/video di sini
                        }),
                        
                        // BODY: Isi Pesan Utama
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: caption
                        }),

                        // FOOTER: Teks kecil
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: config.footer
                        }),

                        // NATIVE FLOW: Tombol CTA (Link)
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    "name": "cta_url",
                                    "buttonParamsJson": JSON.stringify({
                                        "display_text": config.buttonText,
                                        "url": config.buttonUrl,
                                        "merchant_url": config.buttonUrl
                                    })
                                }
                                // Kamu bisa tambah tombol copy code disini jika mau
                            ]
                        })
                    })
                }
            }
        }, {});

        // 6. Kirim Pesan ke Channel
        // Gunakan relayMessage untuk format complex seperti ini
        await conn.relayMessage(config.channelJid, msg.message, { 
            messageId: msg.key.id 
        });

        m.reply('✅ Sukses upload media + button ke channel!');

    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal upload. Pastikan Bot adalah Admin di channel tersebut dan ID Channel benar.');
    }
};

handler.help = ['upch <caption+media>'];
handler.tags = ['owner', 'channel'];
handler.command = /^(upch|uploadch)$/i;
handler.owner = true; // Wajib owner agar tidak disalahgunakan

module.exports = handler;