/*
  FITUR KATA-KATA BROKEN HOME (CommonJS)
  Fungsi: Mengirim quotes mendalam tentang keluarga yang tidak utuh.
  Akses: Quotes Lokal (Tanpa API).
*/

let handler = async (m, { conn, usedPrefix, command }) => {
    // 1. DATABASE KATA-KATA BROKEN HOME
    const quotes = [
        "Rumahku bukan lagi tempat ternyaman, tapi tempat dimana aku belajar cara pura-pura baik-baik saja.",
        "Aku tidak pernah membenci perpisahan mereka, aku hanya lelah menjadi alasan agar mereka bisa kembali rukun.",
        "Hal tersulit dari broken home adalah menyadari bahwa yang paling hancur bukanlah rumahnya, tapi mental anaknya.",
        "Mereka bilang aku kurang bersyukur, padahal yang kuinginkan hanya makan malam dengan kedua orang tua di meja yang sama.",
        "Aku belajar dewasa lebih cepat dari usia seharusnya. Tanggung jawab pertama? Menyembunyikan kesedihan dari mata dunia.",
        "Jiwaku lelah menjadi jembatan di antara dua daratan yang sudah memilih untuk saling menjauh.",
        "Luka paling dalam bukan karena ditinggalkan, tapi karena merasa asing di tempat yang seharusnya kamu sebut rumah.",
        "Kami punya atap, tapi tidak punya kehangatan. Itulah definisi rumah bagiku.",
        "Aku tidak mencari ayah atau ibu yang sempurna, aku hanya mencari rumah yang damai.",
        "Hidup di antara dua cinta yang telah mati, dan aku adalah sisa-sisa kenangan yang mereka lupakan.",
        "Aku baik-baik saja, itu adalah kebohongan terbaik yang kuucapkan setiap hari sejak mereka berpisah.",
        "Setiap pulang, yang kutakutkan bukan gelapnya malam, tapi dinginnya suasana di dalam rumah."
    ];

    // 2. Logika Random Picker
    let randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    
    // 3. Susun Pesan
    let caption = `
💔 *BROKEN HOME QUOTES* 💔
━━━━━━━━━━━━━━━━━━
_"${randomQuote}"_
━━━━━━━━━━━━━━━━━━
_Semoga kamu kuat dan tabah._
`.trim();

    // 4. Kirim Pesan
    await conn.sendMessage(m.chat, {
        text: caption,
        contextInfo: {
            externalAdReply: {
                title: "Kuatkan Hatimu",
                body: "Semua akan baik-baik saja.",
                thumbnailUrl: "https://telegra.ph/file/4dfad98455ef5cbe0ca5c-348c939f54ead7c495.jpg", // Gambar estetik/sedih
                sourceUrl: "https://whatsapp.com/channel/0029Vb6AlYhGzzKTecrl092o",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
};

handler.help = ['brokenhome'];
handler.tags = ['quotes'];
handler.command = /^(brokenhome|bhquotes|pilu)$/i; 

module.exports = handler;