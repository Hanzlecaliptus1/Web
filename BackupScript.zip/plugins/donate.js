/*
  FITUR DONASI SLIDE (CAROUSEL)
  Fungsi: Menampilkan metode donasi dalam format kartu geser yang estetik.
  Library: Baileys Interactive Message
*/

const { 
    generateWAMessageFromContent, 
    proto, 
    prepareWAMessageMedia 
} = require('@adiwajshing/baileys');
const axios = require('axios');

let handler = async (m, { conn, usedPrefix, command }) => {
    m.reply('⏳ Memuat daftar donasi...');

    // 1. DATA DONASI (EDIT DI SINI)
    // URL Gambar harus Link Publik (Telegra.ph/Imgur)
    const DONATION_DATA = [
        {
            title: "💰 GOPAY / DANA",
            body: "Scan QRIS di gambar untuk Donasi.\n\nMinimal Rp 5.000\nAtas Nama: Hanz",
            image_url: "https://telegra.ph/file/0c9a0c1a9c394c8b8a599.jpg", // Ganti dengan QRIS/Cover Dana
            buttonText: "QRIS",
            buttonUrl: "https://link.dana.id/qr/xyz"
        },
        {
            title: "🏦 BANK BCA",
            body: "Transfer langsung ke rekening Bank BCA.\n\nNo. Rek: 1234567890\nAtas Nama: Hanz Wijaya",
            image_url: "https://telegra.ph/file/04a081a4b497a7d38a08a.png", // Ganti dengan Logo BCA/Bank
            buttonText: "SALIN REKENING",
            buttonCode: "1234567890" // Teks yang disalin ke clipboard
        },
        {
            title: "💸 SAWERIA / TRAKTEER",
            body: "Donasi via platform kreator.\n\nBisa pakai pulsa/e-wallet lain.",
            image_url: "https://telegra.ph/file/a458b6c43494793f77c38.jpg", // Ganti dengan Logo Saweria
            buttonText: "LINK SAWERIA",
            buttonUrl: "https://saweria.co/hanzbot"
        }
    ];

    try {
        let cards = [];

        for (const [index, item] of DONATION_DATA.entries()) {
            // 2. Persiapkan Media (Download & Upload)
            let mediaMessage = {};
            
            try {
                // Download gambar dari URL
                let response = await axios.get(item.image_url, { responseType: 'arraybuffer' });
                let mediaBuffer = Buffer.from(response.data);

                // Upload ke server WA
                mediaMessage = await prepareWAMessageMedia(
                    { image: mediaBuffer }, 
                    { upload: conn.waUploadToServer }
                );
            } catch (e) {
                 // Jika gagal, gunakan placeholder (kosongkan)
                 console.error(`Gagal memuat gambar untuk ${item.title}:`, e);
            }

            // 3. Susun Tombol
            let button;
            if (item.buttonUrl) {
                // Tombol CTA URL (Link)
                button = {
                    "name": "cta_url",
                    "buttonParamsJson": JSON.stringify({
                        "display_text": item.buttonText,
                        "url": item.buttonUrl,
                        "merchant_url": item.buttonUrl
                    })
                };
            } else if (item.buttonCode) {
                // Tombol CTA COPY (Salin Rekening)
                button = {
                    "name": "cta_copy",
                    "buttonParamsJson": JSON.stringify({
                        "display_text": item.buttonText,
                        "copy_code": item.buttonCode,
                        "id": item.buttonCode
                    })
                };
            }

            // 4. Buat Kartu Slide
            cards.push(proto.Message.InteractiveMessage.Card.create({
                body: proto.Message.InteractiveMessage.Body.create({
                    text: item.body
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: `Metode ${index + 1} dari ${DONATION_DATA.length}`
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                    title: item.title,
                    hasMediaAttachment: !!mediaMessage.imageMessage,
                    ...mediaMessage
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [button]
                })
            }));
        }

        // 5. Buat Pesan Carousel Utama
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `🙏 *TERIMA KASIH TELAH MENDUKUNG*\nGeser kartu di bawah untuk melihat detail Donasi/Sponsor:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "Donasi bersifat sukarela."
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "DONASI SUPPORT BOT",
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({
                            cards: cards
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m });

        // 6. Kirim Pesan
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal memuat daftar donasi. Coba lagi nanti.');
    }
};

handler.help = ['donasi', 'saweria'];
handler.tags = ['info'];
handler.command = /^(donasi|donate|saweria|trakteer)$/i;

module.exports = handler;