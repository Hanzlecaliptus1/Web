let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`❌ *Teksnya mana?*\nContoh: ${usedPrefix + command} sampurasun sadayana`)

    try {
        let result = latinToSunda(text.toLowerCase())
        
        // Kirim Hasil
        await conn.sendMessage(m.chat, { 
            text: `📝 *Aksara Sunda:*\n\n${result}`,
            contextInfo: {
                externalAdReply: {
                    title: "SUNDA SCRIPT CONVERTER",
                    body: "Konversi Latin ke Aksara Sunda",
                    thumbnailUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Aksara_Sunda_Kaganga.svg/1200px-Aksara_Sunda_Kaganga.svg.png",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply('Gagal mengonversi.')
    }
}

handler.help = ['aksarasunda <teks>']
handler.tags = ['tools', 'maker']
handler.command = /^(aksarasunda|sundascript|aksrasunda)$/i

module.exports = handler


// ==========================================
// LIBRARY KONVERSI LOKAL (ENGINE)
// ==========================================
function latinToSunda(str) {
    let i = 0;
    let result = "";
    
    // Mapping Karakter Utama
    const consonants = {
        'k': 'ᮊ', 'q': 'ᮊ', 'g': 'ᮌ', 'ng': 'ᮍ', 'c': 'ᮎ', 'j': '5', 'z': '7',
        'ny': 'ᮑ', 't': 'ᮒ', 'd': 'ᮓ', 'n': 'ᮔ', 'p': 'ᮕ', 'f': 'E', 'v': 'E',
        'b': 'ᮘ', 'm': 'ᮙ', 'y': 'ᮚ', 'r': 'ᮛ', 'l': 'ᮜ', 'w': 'ᮝ', 's': 'ᮞ',
        'x': 'ᮞ', 'h': 'ᮠ', 'kh': 'AE', 'sy': 'AF'
    };
    
    const vowels = {
        'a': 'ᮃ', 'i': 'ᮄ', 'u': 'ᮅ', 'e': 'ᮈ', 'o': 'A', 'é': '9', 'eu': 'ᮩ'
    };

    // Mapping Rarangken (Tanda Baca/Vokal)
    const vowelMarks = {
        'a': '',    // Default (bawaan konsonan)
        'i': 'ᮒ',   // Panghulu
        'u': 'ᮓ',   // Panyuku
        'e': 'ᮔ',   // Pamepet
        'o': 'ᮕ',   // Panolong
        'é': 'ᮦ',   // Panéléng
        'eu': 'ᮩ'   // Paneuleung
    };

    const finalConsonants = {
        'ng': 'ᮀ', // Panyecek
        'r': 'ᮁ',  // Panglayar
        'h': 'ᮂ'   // Pangwisad
    };

    // Helper: Cek apakah karakter adalah vokal
    const isVowel = (char) => "aiueoé".includes(char) || char === 'eu';
    
    // Helper: Cek apakah karakter adalah konsonan
    const isConsonant = (char) => !isVowel(char) && /[a-z]/.test(char);

    while (i < str.length) {
        let char = str[i];
        let nextChar = str[i + 1] || '';
        let nextNextChar = str[i + 2] || '';
        
        // 1. Cek Digraph (ng, ny, kh, sy, eu)
        let twoChars = char + nextChar;
        let threeChars = char + nextChar + nextNextChar; // Untuk 'nge' dsb

        // Handle Spasi/Simbol
        if (/[^a-z0-9é]/.test(char)) {
            result += char;
            i++;
            continue;
        }

        // Handle Vokal Mandiri (di awal kata atau setelah vokal lain)
        if (vowels[twoChars]) { // eu
            result += vowels[twoChars];
            i += 2; continue;
        }
        if (vowels[char]) { // a, i, u, e, o, é
            result += vowels[char];
            i++; continue;
        }

        // Handle Konsonan
        let cons = '';
        let step = 0;

        // Cek konsonan ganda (ng, ny, kh, sy)
        if (consonants[twoChars]) {
            cons = consonants[twoChars];
            step = 2;
        } else if (consonants[char]) {
            cons = consonants[char];
            step = 1;
        }

        if (cons) {
            // Cek huruf setelah konsonan ini
            let nextAfterCons = str[i + step] || '';
            let nextNextAfterCons = str[i + step + 1] || '';
            let v = nextAfterCons;
            let vv = nextAfterCons + nextNextAfterCons; // Cek eu

            if (vv === 'eu') {
                result += cons + vowelMarks['eu'];
                i += step + 2;
            } else if (vowelMarks[v] !== undefined) {
                result += cons + vowelMarks[v];
                i += step + 1;
            } else {
                // Jika tidak diikuti vokal -> Berarti mati (Pamaeh)
                // KECUALI jika huruf mati itu ng, r, h (bisa jadi rarangken akhir)
                
                // Cek apakah ini huruf mati di tengah/akhir
                // Logika sederhana: Tambah Pamaeh (᮪)
                
                // Khusus ng, r, h di akhir suku kata
                // Logika complex di skip agar script ringan. 
                // Kita gunakan logika dasar: Konsonan + Pamaeh
                
                result += cons + '᮪';
                i += step;
            }
        } else {
            // Karakter tak dikenal
            result += char;
            i++;
        }
    }
    
    // Fix regex sederhana untuk merapikan hasil Rarangken Akhir (ng, r, h) yang salah jadi Pamaeh
    // ᮍ᮪ -> ᮀ (ng mati -> panyecek)
    // ᮛ᮪ -> ᮁ (r mati -> panglayar)
    // ᮠ᮪ -> ᮂ (h mati -> pangwisad)
    result = result.replace(/ᮍ᮪/g, 'ᮀ').replace(/ᮛ᮪/g, 'ᮁ').replace(/ᮠ᮪/g, 'ᮂ');

    return result;
}