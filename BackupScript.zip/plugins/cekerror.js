/*
  FITUR CEK ERROR PLUGIN (CommonJS)
  Fungsi: Memindai folder plugins untuk mencari file yang error/corrupt.
  Akses: KHUSUS OWNER.
*/

const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
    // 1. Validasi Owner
    if (!isOwner) return m.reply('❌ Fitur ini khusus Owner untuk debugging.');

    m.reply('🔍 *SCANNING...*\nSedang memeriksa seluruh file plugin, mohon tunggu...');

    try {
        // 2. Tentukan Lokasi Folder Plugins
        // __dirname mengacu pada lokasi file ini berada (folder plugins)
        let pluginFolder = __dirname;
        
        // Ambil semua file berakhiran .js
        let files = fs.readdirSync(pluginFolder).filter(v => v.endsWith('.js'));
        
        let errorFiles = [];
        let totalFiles = files.length;

        // 3. Mulai Loop Pengecekan
        for (let file of files) {
            let filePath = path.join(pluginFolder, file);
            
            try {
                // Coba require (load) file tersebut
                // Kita hapus cache dulu agar nodejs dipaksa membaca ulang file
                try { delete require.cache[require.resolve(filePath)] } catch (e) {}
                
                require(filePath);
                
            } catch (e) {
                // 4. Jika Terjadi Error, Catat!
                errorFiles.push({
                    name: file,
                    error: e.message, // Pesan error singkat
                    stack: e.stack    // Detail error
                });
            }
        }

        // 5. Tampilkan Hasil
        if (errorFiles.length > 0) {
            let report = `⚠️ *DITEMUKAN ${errorFiles.length} FILE ERROR*\n` +
                         `📂 Dari total ${totalFiles} plugins.\n` +
                         `──────────────────\n`;

            errorFiles.forEach((err, i) => {
                report += `\n📄 *${i + 1}. ${err.name}*\n` +
                          `❌ *Log:* ${err.error}\n` +
                          `──────────────────`;
            });

            report += `\n\n_Segera perbaiki file tersebut atau hapus menggunakan ${usedPrefix}df_`;
            
            await m.reply(report);
        } else {
            await m.reply(`✅ *AMAN JAYA!* \n\nTelurusi ${totalFiles} plugins.\nTidak ditemukan Syntax Error sama sekali.`);
        }

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat mencoba memindai folder.');
    }
};

handler.help = ['cekerror', 'scanerror'];
handler.tags = ['owner', 'host'];
handler.command = /^(cekerror|scanerror|cekplugins)$/i;
handler.owner = true;

module.exports = handler;