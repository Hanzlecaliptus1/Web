/**
 ╔══════════════════════
      ⧉  [Toanime] — [maker]
 ╚══════════════════════

  ✺ Type     : Plugin CJS
  ✺ Source   : https://whatsapp.com/channel/0029VbAXhS26WaKugBLx4E05
  ✺ Creator  : SXZnightmare
  ✺ API      : [ https://zelapioffciall.koyeb.app ]
  ✺ Req      : Hazel (62851××××)
  ✺ Note     : Bisa reply + link image, Uploader sesuaikan struktur script kalian.
*/

const fetch = require('node-fetch') // Pastikan sudah npm install node-fetch
// Sesuaikan path uploader kamu di bawah ini
const { uploader } = require('../lib/uploader') 
// const uploadImage = require('../lib/uploadImage') // Gunakan ini jika file uploader kamu namanya uploadImage

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || ''
        
        if (!text && !/image\/(jpe?g|png|webp)/.test(mime)) {
            return m.reply(`*Contoh: ${usedPrefix + command} (Link gambar)*\n*Atau reply gambarnya.*`)
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

        let imageUrl = text
        if (/image\/(jpe?g|png|webp)/.test(mime)) {
            const buffer = await q.download()
            
            // --- BAGIAN UPLOADER ---
            const uploaded = await uploader(buffer)
            // const uploaded = await uploadImage(buffer) // Ganti baris ini jika pakai uploadImage
            
            imageUrl = uploaded.url || uploaded
        }

        if (!imageUrl) {
            return m.reply(`*🍂 Gagal membaca gambar/gagal upload.*`)
        }

        const endpoint = `https://zelapioffciall.koyeb.app/imagecreator/toanime?url=${encodeURIComponent(imageUrl)}`
        const r = await fetch(endpoint)
        
        if (!r.ok) {
            return m.reply(`*🍂 Gagal mengonversi gambar menjadi anime.*`)
        }
        
        const animeBuffer = Buffer.from(await r.arrayBuffer())

        await conn.sendMessage(
            m.chat,
            {
                image: animeBuffer,
                caption: `*🎨 Gambar berhasil diubah menjadi Anime ✨*`
            },
            { quoted: m }
        )

    } catch (e) {
        console.log(e)
        await m.reply(`*🍂 Terjadi kesalahan saat memproses gambar.*`)
    } finally {
        await conn.sendMessage(m.chat, { react: { text: '', key: m.key } })
    }
}

handler.help = ['toanime']
handler.tags = ['maker']
handler.command = /^(toanime|animeconv|animeconvert)$/i
handler.limit = true
handler.register = false 

module.exports = handler