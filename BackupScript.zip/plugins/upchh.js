/*
  FITUR UPLOAD CHANNEL SIMPLE BUTTON (CommonJS)
  Fungsi: Upload Teks/Gambar/Video ke Channel dengan 1 Tombol Link.
*/

const { 
    generateWAMessageFromContent, 
    proto, 
    prepareWAMessageMedia 
} = require('@adiwajshing/baileys');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // --- KONFIGURASI (GANTI DI SINI) ---
    const channelID = "120363400444882911@newsletter"; // ID Channel Kamu
    const buttonText = "🌐 Buka Tautan";                 // Tulisan di Tombol
    const buttonLink = "https://whatsapp.com/channel/0029Vb6AlYhGzzKTecrl092o";  // Link Tujuan
    // -----------------------------------

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    let caption = text || q.text || '';

    // Validasi: Harus ada pesan (Caption atau Media)
    if (!caption && !mime) {
        return m.reply(`⚠️ *Format Salah!*\nKirim/Reply Media atau ketik pesan:\n*${usedPrefix + command}* Halo ini pesan test`);
    }

    m.reply('⏳ Mengirim ke channel...');

    try {
        let headerConfig = {
            title: "", 
            subtitle: "",
            hasMediaAttachment: false
        };

        // 1. Cek Apakah Ada Media (Gambar/Video)?
        if (/image|video/.test(mime)) {
            let mediaBuffer = await q.download();
            let mediaType = mime.includes('video') ? 'video' : 'image';
            
            // Upload Media dulu
            let mediaUpload = await prepareWAMessageMedia(
                { [mediaType]: mediaBuffer }, 
                { upload: conn.waUploadToServer }
            );

            headerConfig = {
                hasMediaAttachment: true,
                ...mediaUpload
            };
        }

        // 2. Buat Pesan Tombol
        let msg = generateWAMessageFromContent(channelID, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        // Header: Media (Jika ada)
                        header: proto.Message.InteractiveMessage.Header.create(headerConfig),
                        
                        // Body: Caption Pesan
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: caption
                        }),

                        // Footer: Teks Kecil
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "HanzOfficial"
                        }),

                        // Native Flow: Tombol Link
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    "name": "cta_url",
                                    "buttonParamsJson": JSON.stringify({
                                        "display_text": buttonText,
                                        "url": buttonLink,
                                        "merchant_url": buttonLink
                                    })
                                }
                            ]
                        })
                    })
                }
            }
        }, {});

        // 3. Kirim via Relay
        await conn.relayMessage(channelID, msg.message, { 
            messageId: msg.key.id 
        });

        m.reply('✅ Terkirim!');

    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal. Pastikan ID Channel benar & Bot adalah Admin.');
    }
};

handler.help = ['upsimple'];
handler.tags = ['owner'];
handler.command = /^(upsimple|upch2)$/i;
handler.owner = true;

module.exports = handler;