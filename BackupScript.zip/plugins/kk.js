/*
  FITUR KATA BANG HANZ (SIMPLE & CEPAT)
  Command: .hanzquotes
  Fungsi: Random quotes lokal tanpa API.
*/

let handler = async (m, { conn }) => {
    // 1. DATABASE KATA-KATA PILIHAN BANG HANZ
    const quotes = [
        "Jalani hidupmu seperti mendaki gunung. Lihat ke atas, bukan ke bawah. Sekalipun capek, hasilnya indah.",
        "Puncak tertinggi dari masalah adalah sadar bahwa kamu tidak sendiri. Semangat!",
        "Kata Bang Hanz: 'Kalau mimpimu belum ditertawakan orang lain, berarti mimpimu masih terlalu kecil.'",
        "Seberat apapun masalahmu, jangan lupa makan. Pura-pura bahagia itu butuh tenaga.",
        "Bukan siapa yang memujimu di hadapanmu, tapi siapa yang menjagamu di belakangmu.",
        "Jangan bandingkan prosesmu dengan orang lain. Bunga tidak mekar secara bersamaan.",
        "Sabar itu ilmu tingkat tinggi. Belajarnya setiap hari, latihannya setiap saat, ujiannya sering mendadak.",
        "Kalau capek istirahat, bukan berhenti. Ingat, cicilan dan impian masih menumpuk.",
        "Lebih baik dibenci karena menjadi diri sendiri, daripada disukai tapi berpura-pura menjadi orang lain.",
        "Jadilah seperti kopi, yang tetap dicintai tanpa menyembunyikan pahitnya diri.",
        "Hanz be like: 'Chat gak dibales? Positif thinking aja, mungkin dia lagi sibuk... sibuk sayang sama yang lain.'",
        "Balas dendam terbaik adalah menjadikan dirimu lebih baik.",
        "Waktu adalah uang, tapi uang tidak bisa membeli waktu. Hargai setiap detiknya.",
        "Jangan menuntut Tuhan untuk menepati janji-Nya, jika kamu sendiri sering ingkar pada-Nya."
    ];

    // 2. Logika Random Picker
    let randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    
    // 3. Format Waktu Hari Ini
    let d = new Date(new Date + 3600000);
    let locale = 'id';
    let date = d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });

    // 4. Susun Pesan
    let caption = `
🗣️ *KATA-KATA HARI INI BANG HANZ*
📅 *${date}*
━━━━━━━━━━━━━━━━━━
_"${randomQuote}"_
━━━━━━━━━━━━━━━━━━
`.trim();

    // 5. Kirim Pesan
    await m.reply(caption);
};

handler.help = ['hanzquotes'];
handler.tags = ['quotes', 'fun'];
handler.command = /^(hanzquotes|hanz|banghanz|kth)$/i; 

module.exports = handler;