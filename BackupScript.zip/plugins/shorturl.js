const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  // 1. Validasi Input
  if (!text) {
    return m.reply(`
⚠️ *Link mana yang mau disingkat?*

Contoh penggunaan:
*${usedPrefix + command} https://www.google.com/search?q=hanz*
    `.trim());
  }

  // 2. Cek apakah text diawali http/https
  if (!/^https?:\/\//.test(text)) {
    return m.reply('❌ *URL Invalid!* Harap sertakan http:// atau https:// di awal link.');
  }

  await m.reply('⏳ *Sedang memproses link...*');

  try {
    // --- COBA PROVIDER 1: TINYURL (Paling Stabil) ---
    try {
      const tiny = await axios.get(`https://tinyurl.com/api-create.php?url=${text}`);
      return sendResult(m, conn, text, tiny.data, 'TinyURL');
    } catch (e) {
      console.log('TinyURL Failed, trying Is.gd...');
    }

    // --- COBA PROVIDER 2: IS.GD (Alternatif Ringan) ---
    try {
      const isgd = await axios.get(`https://is.gd/create.php?format=json&url=${text}`);
      if (isgd.data.shorturl) {
        return sendResult(m, conn, text, isgd.data.shorturl, 'Is.gd');
      }
    } catch (e) {
      console.log('Is.gd Failed, trying CleanURI...');
    }

    // --- COBA PROVIDER 3: CLEANURI (Cadangan Terakhir) ---
    try {
      const clean = await axios.post('https://cleanuri.com/api/v1/shorten', { url: text });
      if (clean.data.result_url) {
        return sendResult(m, conn, text, clean.data.result_url, 'CleanURI');
      }
    } catch (e) {
      throw new Error('Semua server sibuk.');
    }

  } catch (e) {
    console.error(e);
    m.reply('❌ *Gagal menyingkat URL.* Pastikan link valid dan server tujuan bisa diakses.');
  }
};

// Fungsi Helper untuk mengirim pesan hasil yang rapi
async function sendResult(m, conn, original, short, server) {
  const message = `
✅ *URL SHORTENER SUCCESS*

🔗 *Server:* ${server}
📂 *Original:* ${original}

✨ *Short Link:*
${short}
  `.trim();

  await conn.sendMessage(m.chat, { text: message }, { quoted: m });
}

handler.help = ['shorturl', 'short'];
handler.command = /^(short|shorturl|bitly|tinyurl)$/i;
handler.tags = ['tools'];

module.exports = handler;