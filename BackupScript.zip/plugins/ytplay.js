/*
  FITUR PLAY YOUTUBE (FIXED VERSION)
  Fitur: Multi-Server Support (Anti Down).
  Jika Server 1 Gagal -> Otomatis Pindah Server 2.
*/

const yts = require('yt-search');
const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // 1. Validasi Input
    if (!text) return m.reply(
        `🎵 *Play YouTube*\n\n` +
        `Ketik judul lagu yang mau dicari:\n` +
        `Contoh: *${usedPrefix + command}* Nemen NDX`
    );

    await conn.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });
    m.reply('🔍 *Mencari lagu...*');

    try {
        // 2. Cari di YouTube
        let search = await yts(text);
        let vid = search.all[0];
        
        if (!vid) return m.reply('❌ Lagu tidak ditemukan!');

        let { title, thumbnail, timestamp, views, ago, url, author } = vid;

        // 3. Kirim Info Lagu Dulu (Biar user tau bot merespon)
        let infoMsg = `╭─── [ 🎵 *PLAYING* ] ───\n` +
                      `│\n` +
                      `│ 📌 *Judul:* ${title}\n` +
                      `│ ⏱️ *Durasi:* ${timestamp}\n` +
                      `│ 👤 *Channel:* ${author.name}\n` +
                      `│ 📅 *Upload:* ${ago}\n` +
                      `│\n` +
                      `╰──────────────────────\n` +
                      `_⏳ Sedang mengambil audio dari server..._`;

        await conn.sendMessage(m.chat, {
            text: infoMsg,
            contextInfo: {
                externalAdReply: {
                    title: title,
                    body: "YouTube Audio Player",
                    thumbnailUrl: thumbnail,
                    sourceUrl: url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

        // 4. PROSES DOWNLOAD (MULTI-SERVER)
        let audioUrl = null;

        // -- PERCOBAAN 1: API Ryzendesu --
        try {
            let api1 = await axios.get(`https://api.botcahx.eu.org/api/dowloader/yt?url=$`);
            if (api1.data && api1.data.url) {
                audioUrl = api1.data.url;
            }
        } catch (e) {
            console.log("Server 1 Gagal, mencoba Server 2...");
        }

        // -- PERCOBAAN 2: API Widipe (Cadangan jika Server 1 Gagal) --
        if (!audioUrl) {
            try {
                let api2 = await axios.get(`https://api.botcahx.eu.org/api/dowloader/yt?url=$`);
                if (api2.data && api2.data.result && api2.data.result.mp3) {
                    audioUrl = api2.data.result.mp3;
                }
            } catch (e) {
                console.log("Server 2 Gagal.");
            }
        }

        if (!audioUrl) {
            return m.reply('❌ Maaf, semua server download sedang sibuk. Coba judul lain atau coba lagi nanti.');
        }

        // 5. Kirim Audio
        await conn.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            contextInfo: {
                externalAdReply: {
                    title: title,
                    body: author.name,
                    thumbnailUrl: thumbnail,
                    sourceUrl: url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan sistem.');
    }
};

handler.help = ['play'];
handler.tags = ['downloader'];
handler.command = /^(play|lagu|ytplay)$/i;

module.exports = handler;