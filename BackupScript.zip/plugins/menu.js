process.env.TZ = 'Asia/Jakarta'

let fs = require('fs')

let path = require('path')

let fetch = require('node-fetch')

let moment = require('moment-timezone')

let levelling = require('../lib/levelling')

// --- 1. FUNGSI STYLE (Original) ---

const style = (text) => {

    return text; 

}

// --- 2. DATABASE KATEGORI ---

let arrayMenu = [

  'all', 'ai', 'main', 'downloader', 'database', 'rpg', 'sticker', 

  'advanced', 'xp', 'fun', 'game', 'group', 'image', 'info', 

  'internet', 'islam', 'maker', 'owner', 'voice', 'tools', 'anonymous'

]

const allTags = {

    'all': 'SEMUA MENU', 'ai': 'AI ASSISTANT', 'main': 'MENU UTAMA', 

    'downloader': 'DOWNLOADER', 'database': 'DATABASE', 'rpg': 'RPG GAMES', 

    'sticker': 'STICKER', 'advanced': 'ADVANCED', 'xp': 'EXP & LIMIT', 

    'fun': 'FUN ZONE', 'game': 'GAMES', 'group': 'GROUP TOOLS', 

    'image': 'IMAGE EDIT', 'info': 'INFORMASI', 'internet': 'INTERNET', 

    'islam': 'ISLAMI', 'maker': 'MAKER', 'owner': 'OWNER', 

    'voice': 'VOICE', 'tools': 'TOOLS', 'anonymous': 'ANONYMOUS', '': 'LAINNYA'

}

// --- 3. TAMPILAN DESAIN ---

const defaultMenu = {

    before: `

╭─── [ *DASHBOARD* ] ───⳹

│

│ 👋 *Welcome back, %name*

│

│ 💎 *Membership Status:*

│ ➤ %role

│

│ 📊 *Performance:*

│ ➤ Limit   : %limit

│ ➤ Level   : %level

│

│ 📅 %date • %time

│ 🌐 %uptime

│

╰──────────────────⳹

╭── [ *DAFTAR MENU* ] ────⳹`.trimStart(),

    header: '│\n├  *📂 %category*',

    body: '│  ᯓ✦ %cmd %islimit %isPremium',

    footer: '│\n╰──────────────────⳹',

    after: `\n> ➠ *Powered By Hanz Offc*`

}

let handler = async (m, { conn, usedPrefix: _p, args = [], command }) => {

    try {

        // --- DATA USER & WAKTU ---

        let package = JSON.parse(await fs.promises.readFile(path.join(__dirname, '../package.json')).catch(_ => '{}'))

        let userData = global.db.data.users[m.sender] || {}

        let { exp = 0, limit = 0, level = 0, role = 'User' } = userData

        

        let d = moment.tz('Asia/Jakarta')

        let date = d.format('DD/MM/YYYY')

        let time = d.format('HH:mm')

        let _uptime = process.uptime() * 1000

        let uptime = clockString(_uptime)

        

        // Nama User

        let name = m.pushName || conn.getName(m.sender)

        let botName = global.namebot || 'HanzBot'

        // --- FAKE REPLY OBJECT ---

        let fkontak = {

            key: {

                fromMe: false,

                participant: `0@s.whatsapp.net`, 

                ...(m.chat ? { remoteJid: `status@broadcast` } : {}) 

            },

            message: {

                contactMessage: {

                    displayName: `${name}`,

                    vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`

                }

            }

        }

        // --- LOGIKA MENU ---

        let teks = args[0] || ''

        

        let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {

            return {

                help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],

                tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],

                prefix: 'customPrefix' in plugin,

                limit: plugin.limit,

                premium: plugin.premium,

                enabled: !plugin.disabled,

            }

        })

        let text = ''

        if (!teks) {

            let totalCommands = help.reduce((acc, h) => acc + (h.help ? h.help.length : 0), 0)

            text = defaultMenu.before + `\n│\n`

            for (let tag of arrayMenu) {

                if (tag && allTags[tag]) {

                    text += `│  ᯓ✦ ${_p}menu ${tag}\n`

                }

            }

            text += `│\n╰──────────────────⳹\n\n> ➠ *Total Fitur:* ${totalCommands}`

        } else {

            if (!allTags[teks]) return m.reply(`❌ Kategori "${teks}" tidak ditemukan.`)

            text = defaultMenu.before + '\n'

            const renderMenu = (tag) => {

                let res = defaultMenu.header.replace(/%category/g, allTags[tag]) + '\n'

                let categoryCommands = help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help)

                for (let menu of categoryCommands) {

                    for (let helpCmd of menu.help) {

                        let cmdPretty = menu.prefix ? helpCmd : _p + helpCmd

                        res += defaultMenu.body

                            .replace(/%cmd/g, cmdPretty)

                            .replace(/%islimit/g, menu.limit ? ' 🅛 ' : '')

                            .replace(/%isPremium/g, menu.premium ? '🅟 ' : '') + '\n'

                    }

                }

                return res

            }

            if (teks === 'all') {

                for (let tag of arrayMenu) {

                    if (tag !== 'all' && allTags[tag]) {

                        text += renderMenu(tag)

                    }

                }

            } else {

                text += renderMenu(teks)

            }

            text += defaultMenu.footer + defaultMenu.after

        }

        // Replace Variable

        let replace = {

            '%': '%',

            p: _p,

            uptime,

            name,

            date,

            time,

            level,

            limit,

            role,

            me: botName

        }

        

        let finalMessage = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])

        // --- PENGIRIMAN DENGAN 2 THUMBNAIL (VIDEO UTAMA + IMAGE HEADER) ---

        

        // 1. URL VIDEO (Pesan Utama) - Pastikan link video mp4 valid

        let thumbMainVideo = 'https://files.catbox.moe/6g8l70.mp4' 

        

        // 2. URL IMAGE (Header ExternalAdReply) - Pastikan link gambar jpg/png valid

        let thumbSecImage = 'https://files.catbox.moe/uifi36.jpg'

        // Kirim Pesan Video + Caption + ExternalAdReply

        await conn.sendMessage(m.chat, {

            video: { url: thumbMainVideo }, // Menggunakan key 'video'

            gifPlayback: true, // AUTO LOOP (Videonya muter terus kaya GIF)

            caption: finalMessage,

            contextInfo: {

                mentionedJid: [m.sender],

                externalAdReply: {

                    title: "HANZ BOT SYSTEM",

                    body: "Version 3.5.0 (Public)",

                    thumbnailUrl: thumbSecImage, // Thumbnail Header harus IMAGE

                    sourceUrl: 'https://whatsapp.com/channel/0029Vb6AlYhGzzKTecrl092o',

                    mediaType: 1, // 1 = Image

                    renderLargerThumbnail: true

                }

            }

        }, { quoted: fkontak }) 

        // 2. Kirim Audio (VN)

        await conn.sendMessage(m.chat, { 

            audio: { url: 'https://files.catbox.moe/z6jsay.mp3' }, 

            mimetype: 'audio/mpeg', 

            ptt: true 

        }, { quoted: m })

    } catch (e) {

        conn.reply(m.chat, 'Maaf, menu sedang error', m)

        console.error(e)

    }

}

handler.help = ['menu']

handler.tags = ['main']

handler.command = /^(menu|help|list)$/i

handler.exp = 3

module.exports = handler

// Helper: Konversi Detik ke Jam:Menit

function clockString(ms) {

    if (isNaN(ms)) return '--'

    let h = Math.floor(ms / 3600000)

    let m = Math.floor(ms / 60000) % 60

    let s = Math.floor(ms / 1000) % 60

    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')

}