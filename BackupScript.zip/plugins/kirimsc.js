/*
  FITUR KIRIM SCRIPT / BACKUP SC (CommonJS)
  Fungsi: Mengompres folder bot menjadi ZIP dan mengirimkannya ke Owner.
  Excluded: node_modules, .git, session, tmp (Agar file kecil).
*/

const fs = require('fs');
const { exec } = require('child_process');

let handler = async (m, { conn, isOwner, usedPrefix, command }) => {
    // 1. Validasi Owner (Wajib demi keamanan)
    if (!isOwner) return m.reply('❌ *AKSES DITOLAK*\nFitur ini hanya untuk Owner untuk mengambil backup script.');

    m.reply('⏳ *Sedang mengompres script...*\nMohon tunggu, proses ini memakan waktu tergantung ukuran file.');

    // 2. Nama File Output
    let zipFileName = 'Script-Backup.zip';

    // 3. Perintah Terminal untuk ZIP
    // -r : Recursive (semua folder)
    // -x : Exclude (yang tidak ikut di-zip)
    // Kita skip node_modules, .git, folder session, dan file zip itu sendiri
    let cmd = `zip -r ${zipFileName} . -x "node_modules/*" -x ".git/*" -x "session/*" -x "sessions/*" -x "tmp/*" -x "${zipFileName}"`;

    // 4. Eksekusi
    exec(cmd, async (err, stdout, stderr) => {
        if (err) {
            console.error(err);
            return m.reply('❌ Gagal melakukan ZIP.\nPastikan `zip` sudah terinstall di server (apt install zip).');
        }

        // 5. Cek Apakah File Terbentuk
        if (!fs.existsSync(zipFileName)) {
            return m.reply('❌ Gagal, file zip tidak ditemukan.');
        }

        // 6. Kirim File
        let fileBuffer = fs.readFileSync(zipFileName);
        
        await conn.sendMessage(m.chat, { 
            document: fileBuffer, 
            mimetype: 'application/zip', 
            fileName: zipFileName,
            caption: '✅ *BACKUP SCRIPT SELESAI*\n\n_Note: Node_modules dan Session tidak disertakan agar file ringan._'
        }, { quoted: m });

        // 7. Hapus File Zip Setelah Dikirim (Agar tidak menuhin server)
        fs.unlinkSync(zipFileName);
    });
};

handler.help = ['getsc', 'backup'];
handler.tags = ['owner', 'host'];
handler.command = /^(getsc|sc|script|kirimsc|backup)$/i;
handler.owner = true;

module.exports = handler;