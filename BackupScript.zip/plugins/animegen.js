const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`🌸 *Masukkan deskripsi waifu/karakter!*\nContoh: *${usedPrefix + command} beautiful anime girl, white hair, blue eyes, kimono, cherry blossom background*`);
    
    m.reply('🌸 *Sedang menggambar anime...*');
    try {
        // API yang menggunakan model khusus anime (misal: Prodia/AnythingV5 via scraper)
        let url = `https://widipe.com/anime/text2img?prompt=${encodeURIComponent(text)}`;
        
        await conn.sendMessage(m.chat, { image: { url: url }, caption: `🌸 *Anime Result:* ${text}` }, { quoted: m });
    } catch (e) {
        m.reply('❌ Gagal membuat gambar anime.');
    }
}
handler.help = ['animegen <prompt>'];
handler.tags = ['ai'];
handler.command = /^(animegen|wibuimg)$/i;
handler.limit = true;
module.exports = handler;