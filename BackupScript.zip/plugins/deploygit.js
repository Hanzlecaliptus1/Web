//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
const axios = require('axios');

// --- KONFIGURASI (ISI DENGAN DATA GITHUB MU) ---
const GITHUB_TOKEN = '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'; // Ganti dengan Token GitHub (Classic)
const GITHUB_USERNAME = 'Hanzlecaliptus1';      // Ganti Username GitHub
const REPO_NAME = 'Web';                 // Ganti Nama Repository

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    // 1. Validasi Input
    if (!text) {
      return m.reply(`
🛠️ *CREATE WEBSITE MANAGER*

Fitur ini memungkinkan kamu membuat website HTML statis yang online selamanya via GitHub Pages.

*Cara Pakai:*
1. Custom HTML:
   ${usedPrefix + command} nama-web|kode-html
   _Contoh: ${usedPrefix + command} bioku|<h1>Halo Dunia</h1>_

2. Pakai Template (Otomatis):
   ${usedPrefix + command} nama-web
   _Contoh: ${usedPrefix + command} toko-hacker_
      `.trim());
    }

    // 2. Parsing Data
    let [pageName, htmlContent] = text.split('|');
    
    // Sanitasi nama file (huruf kecil, angka, strip)
    let fileName = pageName.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
    
    if (fileName.length < 3) return m.reply('❌ Nama website minimal 3 karakter!');

    // 3. Cek apakah user kirim HTML atau mau pakai Template
    if (!htmlContent) {
      // Jika kosong, pakai template default keren
      htmlContent = getHackerTemplate(fileName);
      m.reply('🎨 *Kode HTML tidak terdeteksi.*\nMenggunakan Template Default "Hacker Portfolio"...');
    } else {
      m.reply('⚙️ *Memproses kode HTML kustom kamu...*');
    }

    m.reply('🚀 *Sedang mengupload ke Server...*\nMohon tunggu sebentar...');

    // 4. Encode ke Base64 (Syarat API GitHub)
    const contentBase64 = Buffer.from(htmlContent).toString('base64');
    
    // Path file di repo (misal: websites/namafile.html)
    const targetPath = `${fileName}.html`; 
    const apiUrl = `https://api.github.com/repos/${GITHUB_USERNAME}/${REPO_NAME}/contents/${targetPath}`;

    // 5. Request Upload (PUT)
    await axios.put(apiUrl, {
      message: `Deployed via Bot: ${fileName}`,
      content: contentBase64,
      branch: 'main'
    }, {
      headers: {
        'Authorization': `Bearer ${GITHUB_TOKEN}`,
        'Content-Type': 'application/json',
        'User-Agent': 'NodeJS-Bot'
      }
    });

    // 6. Generate Link
    const liveUrl = `https://${GITHUB_USERNAME}.github.io/${REPO_NAME}/${targetPath}`;
    const rawUrl = `https://raw.githubusercontent.com/${GITHUB_USERNAME}/${REPO_NAME}/main/${targetPath}`;

    // 7. Kirim Sukses
    let caption = `✅ *WEBSITE BERHASIL DIBUAT!*\n\n` +
                  `📂 *Nama:* ${fileName}\n` +
                  `🌐 *Link:* ${liveUrl}\n` +
                  `📝 *Type:* Static HTML\n\n` +
                  `_Note: Jika link 404, tunggu 1-2 menit agar GitHub selesai memproses._`;

    // Fake Reply Style
    let fkontak = {
        key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },
        message: { contactMessage: { displayName: `Web Builder`, vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:GitHub\nEND:VCARD` } }
    };

    await conn.sendMessage(m.chat, { 
        text: caption,
        contextInfo: {
            externalAdReply: {
                title: '🚀 WEBSITE DEPLOYER',
                body: 'Click to open your website',
                thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/1005/1005141.png',
                sourceUrl: liveUrl,
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: fkontak });

  } catch (e) {
    console.error(e);
    if (e.response && e.response.status === 422) {
        return m.reply(`❌ Nama website "${text.split('|')[0]}" sudah ada. Gunakan nama lain.`);
    }
    m.reply('❌ Gagal membuat website. Cek token GitHub atau koneksi.');
  }
};

handler.help = ['webmaker'];
handler.command = /^(createweb|buatinweb|webmaker)$/i;
handler.tags = ['tools'];

module.exports = handler;

// --- TEMPLATE DEFAULT (HACKER STYLE) ---
function getHackerTemplate(name) {
  const title = name.toUpperCase();
  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title} | SYSTEM</title>
    <style>
        body { background: #000; color: #0f0; font-family: 'Courier New', monospace; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; overflow: hidden; }
        .container { text-align: center; border: 1px solid #0f0; padding: 40px; box-shadow: 0 0 20px #0f0; animation: glitch 1s infinite; max-width: 90%; }
        h1 { font-size: 3rem; margin: 0; text-shadow: 2px 2px #f00; }
        p { margin-top: 20px; font-size: 1.2rem; }
        .btn { display: inline-block; margin-top: 30px; padding: 10px 20px; border: 1px solid #0f0; color: #0f0; text-decoration: none; transition: 0.3s; }
        .btn:hover { background: #0f0; color: #000; }
        @keyframes glitch {
            0% { transform: translate(0); }
            20% { transform: translate(-2px, 2px); }
            40% { transform: translate(-2px, -2px); }
            60% { transform: translate(2px, 2px); }
            80% { transform: translate(2px, -2px); }
            100% { transform: translate(0); }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>${title}</h1>
        <p>[ SYSTEM ONLINE ]</p>
        <p>Welcome to my digital space.</p>
        <a href="https://wa.me/" class="btn">CONTACT ME</a>
    </div>
</body>
</html>
  `;
}