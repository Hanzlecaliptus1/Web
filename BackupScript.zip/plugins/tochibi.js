/*
  FITUR TO CHIBI (AI IMG2IMG)
  Fungsi: Mengubah foto asli menjadi gaya Chibi Anime.
  Metode: Upload Image -> AI Transformation (Prompting).
*/

const axios = require('axios');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    // 1. Validasi Input
    if (!/image/.test(mime)) {
        return m.reply(`⚠️ Kirim atau Reply foto dengan caption: *${usedPrefix + command}*`);
    }

    m.reply('🎨 *Sedang melukis Chibi...*\nTunggu sebentar, AI sedang bekerja...');

    try {
        // 2. Download Gambar User
        let imgBuffer = await q.download();

        // 3. Upload ke Server (Catbox) untuk dapat URL
        let url = await uploadToCatbox(imgBuffer);
        if (!url) throw new Error('Gagal upload media.');

        // 4. Konfigurasi Prompt Chibi
        // Kita menggunakan API AI Image Generator dengan instruksi khusus
        const prompt = "chibi style, cute, small body, big head, anime style, high quality, masterpiece, vibrant colors";
        const negativePrompt = "ugly, realistic, photo, low quality, blurry, bad anatomy, text, watermark";
        
        // Menggunakan API Ryzendesu (Prodia/Stable Diffusion Engine)
        // Endpoint ini gratis dan support img2img
        const apiUrl = `https://api.ryzendesu.vip/api/ai/prodia-img2img?url=${encodeURIComponent(url)}&prompt=${encodeURIComponent(prompt)}&model=revAnimated-v122.safetensors&negative_prompt=${encodeURIComponent(negativePrompt)}&steps=25&cfg_scale=7&denoising_strength=0.6`;

        // 5. Request ke API
        // Prodia biasanya mengembalikan Buffer langsung atau JSON berisi URL
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        
        // 6. Kirim Hasil
        await conn.sendMessage(m.chat, {
            image: response.data,
            caption: '✨ *TO CHIBI SUCCESS* ✨\nLucu kan?'
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('❌ Gagal membuat gambar Chibi. Server AI mungkin sedang sibuk, coba lagi nanti.');
    }
};

handler.help = ['tochibi'];
handler.tags = ['ai', 'maker'];
handler.command = /^(tochibi|jadianimekecil|chibi)$/i;

module.exports = handler;

// --- HELPER: UPLOAD GAMBAR ---
async function uploadToCatbox(buffer) {
    try {
        const { ext } = await fromBuffer(buffer);
        const bodyForm = new FormData();
        bodyForm.append("fileToUpload", buffer, "file." + ext);
        bodyForm.append("reqtype", "fileupload");

        const res = await axios.post("https://catbox.moe/user/api.php", bodyForm, {
            headers: bodyForm.getHeaders(),
        });

        return res.data;
    } catch (err) {
        console.error("Upload Gagal:", err);
        return null;
    }
}