/*
  COMMAND ON/OFF ANTI LINK ALL
*/

let handler = async (m, { conn, args, usedPrefix, command, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply('Khusus di dalam grup!');
    if (!isAdmin && !isOwner) return m.reply('Khusus Admin Grup!');

    let chat = global.db.data.chats[m.chat];
    
    // Default args
    if (!args[0]) {
        return m.reply(`⚠️ Pilih on atau off!\nContoh: *${usedPrefix + command} on*`);
    }

    if (args[0] === 'on') {
        if (chat.antiLinkAll) return m.reply('⚠️ Anti Link All sudah aktif.');
        chat.antiLinkAll = true;
        m.reply('✅ *Anti Link All Diaktifkan*\nBot akan menghapus SEMUA link yang dikirim member (Tanpa Kick).');
    } else if (args[0] === 'off') {
        if (!chat.antiLinkAll) return m.reply('⚠️ Anti Link All sudah mati.');
        chat.antiLinkAll = false;
        m.reply('❌ *Anti Link All Dinonaktifkan*');
    } else {
        m.reply(`⚠️ Format salah. Ketik *${usedPrefix + command} on* atau *off*`);
    }
};

handler.help = ['antilinkall on/off'];
handler.tags = ['group', 'admin'];
handler.command = /^(antilinkall|antialllink)$/i;
handler.group = true;
handler.admin = true;

module.exports = handler;