const uploadFile = require('../lib/uploadFile')
const uploadImage = require('../lib/uploadImage')
let fetch = require("node-fetch")

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
  // 1. Cek Status Premium
  let user = global.db.data.users[m.sender]
  if (!user.premium && !isOwner) throw `🚩 *Akses Ditolak!* Fitur ini khusus *Premium User*.\n\nSilakan upgrade premium untuk membuat WM Custom & Durasi Video lebih panjang.`

  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  
  // 2. Format Input: Packname|Author
  if (!text) throw `*CONTOH PENGGUNAAN PREMIUM:*\n${usedPrefix + command} Punya Udin|Bot Kece\n\n(Gunakan tanda | untuk memisah Packname dan Author)`;
  
  let [packname, author] = text.split('|')
  packname = packname || 'Sticker Premium' // Default jika kosong
  author = author || 'Bot WhatsApp'         // Default jika kosong

  // 3. Validasi Durasi (Premium dapat 20 detik)
  if (/video/g.test(mime) && (q.msg || q).seconds > 20) return m.reply('🚩 Maksimal 20 detik untuk User Premium!')
  
  m.reply('✨ *Memproses Sticker Premium...*')
      
  try {
    let img = await q.download()
    if (!img) throw `Balas gambar/video/stiker dengan perintah ${usedPrefix + command}`

    // 4. Proses Upload & Convert
    let media = await uploadImage(img, "true")
    
    if (q.isAnimated === true || /video/g.test(mime)) {
      // Menggunakan API untuk convert GIF/Video ke Webp
      let res = await fetch(`https://api.botcahx.eu.org/api/tools/webp2mp4?url=${media}&apikey=${global.btc || 'APIKEY_MU'}`) // Pastikan apikey benar
      let json = await res.json()
      if (!json.result) throw 'Gagal mengubah media ke stiker.'

      // Kirim Video Sticker
      await conn.sendVideoAsSticker(m.chat, json.result, m, {
        packname: packname,
        author: author
      })
    } else {
      // Kirim Image Sticker
      await conn.sendImageAsSticker(m.chat, img, m, {
        packname: packname,
        author: author
      })
    }
  } catch (e) {
    console.log(e)
    m.reply(`❌ Gagal! Pastikan file tidak terlalu besar.`)
  }
}

handler.help = ['wm <packname|author>']
handler.tags = ['premium'] // Pindah ke tag premium
handler.command = /^(wm|watermark|swm)$/i
handler.premium = true; // Wajib Premium
handler.limit = false; // Tidak makan limit

module.exports = handler