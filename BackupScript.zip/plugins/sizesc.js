/*
  FITUR SIZE SCRIPT (CommonJS)
  Fungsi: Menghitung total ukuran file bot (Source Code Only).
  Excluded: node_modules, .git, session, tmp.
*/

const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, usedPrefix, command }) => {
    m.reply('⏳ *Sedang menghitung ukuran file...*\n(Mengabaikan node_modules & session)');

    try {
        // 1. Tentukan Root Folder
        const rootDir = process.cwd();
        
        // 2. Daftar Folder yang DIABAIKAN (Supaya hitungan akurat ke script aja)
        const ignoreList = [
            'node_modules', 
            '.git', 
            'session', 
            'sessions', 
            'tmp', 
            '.npm',
            'package-lock.json',
            'yarn.lock'
        ];

        let totalSize = 0;
        let fileCount = 0;
        let folderCount = 0;

        // 3. Fungsi Rekursif (Scan Folder)
        const scanDirectory = (dir) => {
            const files = fs.readdirSync(dir);

            for (const file of files) {
                const filePath = path.join(dir, file);
                const stats = fs.statSync(filePath);

                // Cek apakah masuk list ignore?
                if (ignoreList.includes(file)) continue;

                if (stats.isDirectory()) {
                    folderCount++;
                    scanDirectory(filePath); // Masuk ke dalam folder
                } else {
                    fileCount++;
                    totalSize += stats.size; // Tambah ukuran file
                }
            }
        };

        // 4. Mulai Scanning
        scanDirectory(rootDir);

        // 5. Format Ukuran (Byte -> KB -> MB)
        const sizeFormatted = formatSize(totalSize);

        // 6. Kirim Hasil
        let caption = `
📂 *INFO UKURAN SCRIPT*
━━━━━━━━━━━━━━━━━━
📦 *Total Size:* ${sizeFormatted}
📄 *Total File:* ${fileCount}
📁 *Total Folder:* ${folderCount}
━━━━━━━━━━━━━━━━━━
_Note: Folder 'node_modules' dan 'session' tidak dihitung agar hasil menunjukkan ukuran murni script._
`.trim();

        await conn.sendMessage(m.chat, { 
            text: caption,
            contextInfo: {
                externalAdReply: {
                    title: "Script Inspector",
                    body: "Server Information",
                    thumbnailUrl: "https://telegra.ph/file/2a06381fd44658718494c.jpg", // Ganti gambar server/coding
                    sourceUrl: "",
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            } 
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat menghitung ukuran file.');
    }
};

handler.help = ['sizescript', 'scsize'];
handler.tags = ['owner', 'info'];
handler.command = /^(sizescript|scsize|ceksc|sizegab)$/i;

// Bisa diset untuk owner saja atau public
// handler.owner = true; 

module.exports = handler;

// --- HELPER FORMAT SIZE ---
function formatSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}