let handler = async (m, { conn, text, command }) => {
    try {
        // 1. Menentukan Target (Siapa yang mau dicek?)
        let who
        if (m.isGroup) {
            // Prioritas: Tag > Reply > Input Nomor > Diri Sendiri
            who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.sender
        } else {
            // Di Private Chat: Input Nomor > Lawan Bicara
            who = text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat
        }

        // 2. Mengambil Data Bio (Status)
        // Note: fetchStatus bisa gagal jika user mem-private bio-nya
        let bio = await conn.fetchStatus(who).catch(_ => {})
        
        // 3. Mengambil Foto Profil
        let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b749c72.jpg') // Gambar default jika tidak ada PP
        
        // 4. Mengambil Nama User
        let username = await conn.getName(who)

        // 5. Jika Bio tidak ditemukan (Private)
        if (!bio || !bio.status) {
            return conn.sendMessage(m.chat, { 
                image: { url: pp }, 
                caption: `🔒 *Bio Diprivate*\n\n👤 *Nama:* ${username}\n🚫 Pengguna ini menyembunyikan info/status WhatsApp-nya.` 
            }, { quoted: m })
        }

        // 6. Format Tanggal Bio dibuat
        let setAt = bio.setAt ? new Date(bio.setAt).toLocaleDateString('id-ID', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
        }) : 'Tidak diketahui'

        // 7. Susun Pesan Keren
        let caption = `👤 *USER BIO INFO* 👤\n\n`
        caption += `📛 *Nama:* ${username}\n`
        caption += `🆔 *Tag:* @${who.split`@`[0]}\n`
        caption += `📅 *Dibuat:* ${setAt}\n`
        caption += `──────────────────\n`
        caption += `📝 *Bio:* \n${bio.status}`

        // 8. Kirim Pesan dengan Foto Profil
        await conn.sendMessage(m.chat, {
            image: { url: pp },
            caption: caption,
            mentions: [who]
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply('❌ Gagal mengambil info. Pastikan nomor valid atau bot tidak diblokir.')
    }
}

handler.help = ['getbio <tag/reply>']
handler.tags = ['stalk']
handler.command = /^(getbio|bio|status|getstatus)$/i

module.exports = handler