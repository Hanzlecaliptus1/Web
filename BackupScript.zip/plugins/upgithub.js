const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    
    // ==========================================
    // 1. KONFIGURASI (EDIT DISINI)
    // ==========================================
    // Masukkan Token GitHub kamu di sini (Awalan ghp_...)
    const ghToken = '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'; 
    
    // Default Owner/Repo jika user malas ngetik (Opsional)
    // Contoh: 'Hanslecaliptus1/Hanzbot'
    const defaultRepo = 'UsernameGithub/NamaRepo'; 
    // ==========================================


    // --- 2. VALIDASI INPUT ---
    // Cek apakah ada file yang di-reply atau dikirim
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!mime) return m.reply(`❌ *Kirim/Reply file ZIP yang mau diupload!*\n\nCara pakai:\n${usedPrefix + command} user/repo\n\nContoh:\n${usedPrefix + command} HanzOffc/BackupBot`);

    // Parsing Nama Repo
    // Jika user mengetik argumen, pakai itu. Jika tidak, pakai default.
    let targetRepo = text ? text : defaultRepo;
    
    // Bersihkan URL jika user mengirim link lengkap (https://github.com/user/repo -> user/repo)
    targetRepo = targetRepo.replace('https://github.com/', '').replace('.git', '');
    
    let [ghUser, ghRepo] = targetRepo.split('/');
    if (!ghUser || !ghRepo) return m.reply('❌ Format repo salah! Harus: *username/repo*');

    // --- 3. VISUAL FAKE REPLY ---
    let fakeGh = {
        key: { fromMe: false, participant: `0@s.whatsapp.net`, remoteJid: 'status@broadcast' },
        message: {
            extendedTextMessage: {
                text: 'GITHUB UPLOADER',
                contextInfo: {
                    externalAdReply: {
                        title: '☁️ GITHUB CLOUD',
                        body: `Target: ${targetRepo}`,
                        thumbnailUrl: 'https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png',
                        sourceUrl: `https://github.com/${targetRepo}`,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }
        }
    }

    await conn.sendMessage(m.chat, { text: '⏳ *Sedang mendownload & mengupload file...*' }, { quoted: fakeGh });

    try {
        // --- 4. PROSES DOWNLOAD & ENCODE ---
        // Download file dari WA
        let mediaBuffer = await q.download();
        
        // GitHub API butuh file dalam bentuk Base64 String
        let contentBase64 = mediaBuffer.toString('base64');
        
        // Tentukan Nama File
        // Jika file punya nama (document), pakai itu. Jika tidak, generate acak.
        let fileName = q.fileName || q.msg?.fileName || `upload_${Date.now()}.${mime.split('/')[1] || 'zip'}`;

        // --- 5. REQUEST KE GITHUB API ---
        // Endpoint: PUT /repos/{owner}/{repo}/contents/{path}
        let apiUrl = `https://api.github.com/repos/${ghUser}/${ghRepo}/contents/${fileName}`;

        await axios.put(apiUrl, {
            message: `Upload via WhatsApp Bot (By ${m.pushName})`, // Commit Message
            content: contentBase64
        }, {
            headers: {
                'Authorization': `Bearer ${ghToken}`,
                'Accept': 'application/vnd.github.v3+json'
            }
        });

        // --- 6. SUKSES ---
        let successText = `✅ *UPLOAD SUCCESS!*\n\n` +
                          `📂 *File:* ${fileName}\n` +
                          `📦 *Repo:* ${targetRepo}\n` +
                          `🔗 *Link:* https://github.com/${targetRepo}/blob/main/${fileName}`;

        await conn.sendMessage(m.chat, { text: successText }, { quoted: fakeGh });

    } catch (e) {
        console.error(e);
        let errMsg = e.response?.data?.message || e.message;
        
        if (errMsg.includes('Bad credentials')) {
            return m.reply('❌ *Token Salah/Expired!* Cek konfigurasi token.');
        }
        if (errMsg.includes('Not Found')) {
            return m.reply('❌ *Repo Tidak Ditemukan!* Pastikan nama repo benar dan Token punya akses.');
        }
        if (errMsg.includes('too large')) {
            return m.reply('❌ *File Terlalu Besar!* GitHub API membatasi upload via API maks 100MB.');
        }

        m.reply(`❌ *Upload Gagal:*\n${errMsg}`);
    }
}

handler.help = ['ghupload <user/repo>'];
handler.tags = ['owner'];
handler.command = /^(ghupload|githubupload|pushzip)$/i;
handler.owner = true; // Wajib Owner

module.exports = handler;