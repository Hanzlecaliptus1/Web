/*
  FITUR SEND FITUR / GET PLUGIN (CommonJS)
  Fungsi: Mencari dan mengirimkan isi source code file plugin.
  Akses: KHUSUS OWNER.
*/

const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, isOwner, command, text, usedPrefix }) => {
    // 1. Validasi Owner
    if (!isOwner) return m.reply('❌ *AKSES DITOLAK*\nFitur ini khusus Owner untuk mengambil script.');

    // 2. Validasi Input
    if (!text) return m.reply(
        `⚠️ *Nama filenya apa?*\n\n` +
        `Contoh:\n*${usedPrefix + command}* menu\n*${usedPrefix + command}* donasi`
    );

    try {
        // 3. Scanning Folder Plugins
        // Menggunakan process.cwd() agar path akurat dari root bot
        const pluginFolder = path.join(process.cwd(), 'plugins');
        
        // Baca semua file di folder plugins
        const files = fs.readdirSync(pluginFolder);
        
        // Cari file yang namanya mengandung input user (Case Insensitive)
        let filename = files.find(f => f.toLowerCase().includes(text.toLowerCase()));

        // 4. Jika File Tidak Ditemukan
        if (!filename) {
            return m.reply(
                `❌ File plugin dengan kata kunci *"${text}"* tidak ditemukan.\n\n` +
                `Coba cek nama aslinya dengan command: *${usedPrefix}listplugin*`
            );
        }

        // 5. Baca Isi File
        let filePath = path.join(pluginFolder, filename);
        let sourceCode = fs.readFileSync(filePath, 'utf-8');

        // 6. Kirim Hasil
        m.reply(`📂 *FOUND:* ${filename}\n\n${sourceCode}`);

    } catch (e) {
        console.error(e);
        m.reply('❌ Terjadi kesalahan saat membaca file. Pastikan folder *plugins* ada.');
    }
};

handler.help = ['getplugin <namafile>', 'sendfitur <namafile>'];
handler.tags = ['owner', 'host'];
handler.command = /^(getplugin|gp|getfitur|sendfitur)$/i;
handler.owner = true;

module.exports = handler;