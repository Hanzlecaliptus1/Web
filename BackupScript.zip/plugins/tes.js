let handler = async (m, { conn }) => {
    // 1. Membuat Objek Fake Reply
    let fakeReply = {
        key: { 
            fromMe: false, 
            participant: '0@s.whatsapp.net', // Seolah dari WhatsApp Official
            remoteJid: 'status@broadcast' 
        },
        message: { 
            conversation: 'Tes Fitur Bot' // Teks yang muncul di dalam quote
        }
    }

    // 2. Kirim pesan dengan Fake Reply
    // Parameter ke-3 adalah options untuk quoted
    await m.reply('Ada apa', false, { quoted: fakeReply })
}

handler.command = ['tes']
handler.tags = ['main']
handler.help = ['tes']

module.exports = handler