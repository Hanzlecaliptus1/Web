let uploadImage = require('../lib/uploadImage') // Pastikan sudah ada file/fungsi ini
let fetch = require('node-fetch')

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    
    // 1. Validasi: Harus Gambar
    if (!mime) throw `Kirim atau Reply gambar QR Code dengan caption *${usedPrefix + command}*`
    if (!/image\/(jpe?g|png)/.test(mime)) throw `Format tidak didukung! Harap kirim gambar QR Code (JPG/PNG).`

    m.reply('🔍 *Sedang memindai QR Code...*')

    try {
        // 2. Download Media
        let img = await q.download()
        
        // 3. Upload ke Internet (Telegra.ph) agar bisa dibaca API
        // Jika error di sini, pastikan fungsi uploadImage di bawah sudah dipasang
        let url = await uploadImage(img)
        
        // 4. Kirim URL gambar ke API Pembaca QR
        let api = await fetch(`http://api.qrserver.com/v1/read-qr-code/?fileurl=${url}`)
        let json = await api.json()

        // 5. Cek Hasilnya
        // Struktur response API: [ { symbol: [ { data: "Isi QR", error: null } ] } ]
        if (!json || !json[0] || !json[0].symbol || !json[0].symbol[0].data) {
            throw '❌ QR Code tidak terbaca atau gambar buram.'
        }

        let hasil = json[0].symbol[0].data

        // 6. Kirim Hasil
        await conn.reply(m.chat, `✅ *QR Code Berhasil Dibaca!*\n\n📄 *Isi:* \n\`${hasil}\``, m)

    } catch (e) {
        console.error(e)
        m.reply('❌ Gagal membaca QR Code. Pastikan gambar jelas dan tidak terpotong.')
    }
}

handler.help = ['readqr', 'scanqr']
handler.tags = ['tools']
handler.command = /^(readqr|scanqr|bacaqr|cekqr)$/i

module.exports = handler