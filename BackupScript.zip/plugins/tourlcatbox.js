const axios = require('axios');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    // 1. Ambil Media (Quoted atau Dikirim langsung)
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    // 2. Validasi
    if (!mime) throw `Kirim/Reply gambar/video/audio dengan caption *${usedPrefix + command}*`;

    m.reply('🚀 *Sedang mengupload ke Catbox...* \n');

    // 3. Download Media ke Buffer
    let media = await q.download();
    if (!media) throw 'Gagal mendownload media.';

    // 4. Proses Upload
    let link = await uploadToCatbox(media);

    // 5. Kirim Hasil
    let caption = `✅ *UPLOAD SUKSES*\n\n` +
                  `🔗 *URL:* ${link}\n` +
                  `📦 *Size:* ${formatSize(media.length)}\n` +
                  `⏳ *Expired:* Never (Permanent)`;

    // Kirim teks berisi link (tanpa preview link agar rapi)
    await m.reply(caption);

  } catch (e) {
    console.error(e);
    m.reply(`❌ Gagal upload: ${e.message || e}`);
  }
};

handler.help = ['tourl'];
handler.tags = ['tools'];
handler.command = /^(catbox|upload|toimg)$/i;

module.exports = handler;

// --- FUNGSI UPLOAD KE CATBOX ---
async function uploadToCatbox(buffer) {
  try {
    // Deteksi tipe file otomatis agar ekstensi benar (jpg, png, mp4, dll)
    const { ext, mime } = await fromBuffer(buffer);
    
    let form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, { filename: 'upload.' + ext, contentType: mime });

    // Request ke Catbox
    let { data } = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
      }
    });

    // Validasi hasil
    if (data && typeof data === 'string' && data.startsWith('http')) {
        return data.trim();
    } else {
        throw 'Respon server bukan URL.';
    }

  } catch (e) {
    throw new Error('Server Catbox Down/Error.');
  }
}

// --- HELPER SIZE ---
function formatSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}