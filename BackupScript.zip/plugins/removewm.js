const axios = require('axios');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    
    if (!mime) throw `Kirim/Reply gambar dengan caption *${usedPrefix + command}*`;
    if (!/image\/(jpe?g|png)/.test(mime)) throw `Format ${mime} tidak didukung. Kirim gambar jpg/png.`;

    m.reply('⏳ Sedang memproses... (Upload ke Catbox -> Remove WM -> Kirim)');

    // 1. Download media
    let imgBuffer = await q.download();

    // 2. Upload ke Catbox (Pengganti Telegra.ph)
    let imageUrl = await uploadToCatbox(imgBuffer);
    console.log('File uploaded to:', imageUrl);

    // 3. Konfigurasi API Remove WM
    // Saya perbaiki URL-nya agar tidak double parameter '?imageUrl='
    let apiEndpoint = `https://api.zenzxz.my.id/api/tools/removewm`;

    // 4. Request ke API
    let { data, headers } = await axios.get(apiEndpoint, {
      params: {
        imageUrl: imageUrl,
        apikey: 'sokepya' // API Key kamu
      },
      responseType: 'arraybuffer' // Kita minta buffer dulu biar aman
    });

    // 5. Cek apakah hasilnya JSON (Error/Link) atau Gambar (Buffer)
    let contentType = headers['content-type'];
    
    if (contentType.includes('application/json')) {
        // Jika response JSON, parse hasilnya
        let res = JSON.parse(data.toString());
        if (res.status === false) throw res.message || 'API Error';
        
        let resultUrl = res.result || res.url || res.data;
        if (!resultUrl) throw 'Gagal parsing JSON response';
        
        await conn.sendFile(m.chat, resultUrl, 'nowm.jpg', '✅ Sukses (Via JSON)', m);
    } else {
        // Jika response bukan JSON (langsung gambar), kirim buffernya
        await conn.sendFile(m.chat, data, 'nowm.jpg', '✅ Sukses (Via Buffer)', m);
    }

  } catch (e) {
    console.error("Error Remove WM:", e);
    m.reply(`Gagal: ${e.message || e}`);
  }
};

handler.help = ['removewm'];
handler.tags = ['tools'];
handler.command = /^(removewm|nowm|hapuswm)$/i;

module.exports = handler;

// --- Helper: Upload Image ke Catbox.moe ---
async function uploadToCatbox(buffer) {
  const { ext, mime } = await fromBuffer(buffer);
  let form = new FormData();
  
  // Parameter wajib Catbox
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', buffer, { filename: 'tmp.' + ext, contentType: mime });
  
  try {
    let { data } = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
      }
    });
    
    // Catbox mengembalikan string URL mentah, bukan JSON
    if (data && typeof data === 'string' && data.startsWith('http')) {
        return data.trim();
    } else {
        throw 'Gagal upload ke Catbox (Respon aneh)';
    }
  } catch (e) {
    throw 'Server Upload Catbox sedang error. Coba lagi nanti.';
  }
}