const axios = require('axios');
const ytSearch = require('yt-search');

let handler = async (m, { conn, usedPrefix, text, command }) => {
    // 1. Validasi Input
    if (!text) return m.reply(
`⚠️ Ketikkan nama lagu atau URL YouTube yang ingin diunduh.

Contoh:
${usedPrefix + command} dj nina
${usedPrefix + command} https://youtu.be/iQo-8wx0l0Y`
    );

    try {
        let videoUrl = text;
        let detail = '';

        // 2. Cek apakah input berupa URL atau Judul Lagu
        if (!text.includes("youtube.com") && !text.includes("youtu.be")) {
            m.reply('🔍 Sedang mencari lagu...');
            
            const search = await ytSearch(text);
            const video = search.all[0];

            if (!video) return m.reply('❌ Lagu yang Anda cari tidak ditemukan.');

            videoUrl = video.url;
            
            detail = 
`🎵 *YouTube MP3 Downloader V2*

📌 *Judul:* ${video.title}
👤 *Channel:* ${video.author.name}
📅 *Upload:* ${video.ago}
👁️ *View:* ${video.views}
🔗 *Link:* ${videoUrl}

⏳ *Sedang mengunduh...*`;
        } else {
            detail = `⏳ *Sedang memproses URL...*\n🔗 ${videoUrl}`;
        }

        // Kirim pesan detail sebelum file dikirim
        await conn.sendMessage(m.chat, { text: detail }, { quoted: m });

        // 3. Request ke API
        const apiUrl = `https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(videoUrl)}`;
        const { data } = await axios.get(apiUrl);

        // 4. Validasi Respon API
        if (!data || !data.result || !data.result.mp3) {
            return m.reply('❌ Gagal mengambil data audio dari server.');
        }

        const { title, thumbnail, duration, mp3 } = data.result;

        // 5. Kirim File Audio
        await conn.sendMessage(m.chat, {
            document: { url: mp3 },
            mimetype: 'audio/mpeg',
            fileName: `${title}.mp3`,
            caption: `✅ *Berhasil didownload!*\n📌 *Judul:* ${title}`
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        m.reply(`❌ Terjadi kesalahan sistem:\n${error.message}`);
    }
};

// Metadata Handler
handler.help = ['play2 <judul/url>'];
handler.tags = ['downloader'];
handler.command = /^(play2|ytmp3-v2|music2|song2)$/i;

module.exports = handler;