/*
  FITUR SEARCH PLUGIN FILE (CommonJS)
  Fungsi: Mencari nama file script/plugin yang ada di database bot.
  Akses: KHUSUS OWNER (Karena menampilkan path file sistem).
*/

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
    // 1. Validasi Owner
    if (!isOwner) return m.reply('❌ *AKSES DITOLAK*\nFitur ini hanya untuk Owner/Developer untuk mencari file sistem.');

    // 2. Validasi Input
    if (!text) return m.reply(
        `⚠️ *Mau cari file apa?*\n\n` +
        `Contoh: *${usedPrefix + command}* menu\n` +
        `(Bot akan mencari semua file yang mengandung kata 'menu')`
    );

    m.reply('🔍 *Sedang menelusuri folder plugins...*');

    // 3. Ambil Data Plugin
    // Object.keys(global.plugins) berisi path lengkap file (misal: /home/container/plugins/main-menu.js)
    let allPlugins = Object.keys(global.plugins);
    let keyword = text.toLowerCase();

    // 4. Filter Pencarian
    let found = allPlugins.filter(pluginPath => {
        // Ambil nama filenya saja biar pencarian lebih relevan
        let filename = pluginPath.replace(/^.*[\\/]/, '').toLowerCase();
        return filename.includes(keyword);
    });

    // 5. Cek Hasil
    if (found.length === 0) {
        return m.reply(`❌ File plugin dengan kata kunci *"${text}"* tidak ditemukan.`);
    }

    // 6. Susun Laporan
    let caption = `📂 *SEARCH PLUGIN RESULT* 📂\n` +
                  `🔑 Keyword: *${text}*\n` +
                  `📊 Ditemukan: *${found.length}* File\n` +
                  `──────────────────\n\n`;

    found.forEach((path, index) => {
        // Bersihkan path agar terlihat rapi (hanya menampilkan nama file)
        let filename = path.replace(/^.*[\\/]/, '');
        caption += `📄 *${index + 1}. ${filename}*\n`;
        // Jika mau menampilkan path lengkap, uncomment baris bawah ini:
        // caption += `   └ ${path}\n`; 
    });

    caption += `\n──────────────────\n` +
               `_Gunakan perintah berikut untuk mengambil/edit isinya:_\n` +
               `• *${usedPrefix}gp* <namafile> (Get Plugin)\n` +
               `• *${usedPrefix}df* <namafile> (Delete Plugin)`;

    // 7. Kirim Hasil
    await m.reply(caption);
};

handler.help = ['searchplugin <namafile>'];
handler.tags = ['owner', 'host'];
handler.command = /^(searchplugin|carifile|findplugin|cpl)$/i;
handler.owner = true;

module.exports = handler;