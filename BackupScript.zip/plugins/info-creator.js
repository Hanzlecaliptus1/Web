let handler = async (m, { conn }) => {

    // ==========================================
    // 📝 KONFIGURASI OWNER (EDIT DISINI)
    // ==========================================
    const namaOwner = 'HANZOFFC'         // Nama Tampilan
    const nomorOwner = '6283893616868'     // Nomor WA (Ganti dengan nomor aslimu)
    const emailOwner = 'hanz@support.com' // Email
    const linkWeb = 'https://instagram.com/hanzoffc' // Link Web/IG
    const region = 'Indonesia'           // Lokasi
    // ==========================================

    // 1. PEMBERSIH NOMOR (PENTING)
    // Membersihkan karakter selain angka agar vCard terbaca valid oleh WA
    const phoneNumber = nomorOwner.replace(/[^0-9]/g, '');

    // 2. STRUKTUR vCARD TERBARU (v3.0)
    // Format ini mendukung tombol "Chat", "Email", dan "Laman Web" langsung di profil
    const vcard = `BEGIN:VCARD
VERSION:3.0
N:;${namaOwner};;;
FN:${namaOwner}
ORG:Hanz Bot Developer
TITLE:Owner
item1.TEL;waid=${phoneNumber}:${phoneNumber}
item1.X-ABLabel:Ponsel
item2.URL:${linkWeb}
item2.X-ABLabel:🌐 Website / Sosmed
item3.EMAIL;type=INTERNET:${emailOwner}
item3.X-ABLabel:📧 Email
item4.ADR:;;${region};;;;
item4.X-ABLabel:📍 Region
NOTE:Harap tidak melakukan Spam Call/Chat.
END:VCARD`

    // 3. FAKE REPLY SIMPEL (Tanpa Gambar Besar)
    // Hanya mengutip kontak palsu agar terlihat rapi
    let fkontak = {
        key: { fromMe: false, participant: `0@s.whatsapp.net`, remoteJid: 'status@broadcast' },
        message: {
            contactMessage: {
                displayName: `${namaOwner}`,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${namaOwner};;;\nFN:${namaOwner}\nitem1.TEL;waid=${phoneNumber}:${phoneNumber}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
            }
        }
    }

    // 4. KIRIM KONTAK
    await conn.sendMessage(m.chat, {
        contacts: { 
            displayName: namaOwner, 
            contacts: [{ vcard }] 
        }
    }, { quoted: fkontak })
    
    // (Opsional) Tambahan teks di bawahnya jika mau
    // await m.reply('Itu nomor owner saya, jangan dispam ya!')
}

handler.help = ['owner', 'creator']
handler.tags = ['info']
handler.command = /^(owner|creator|author)$/i

module.exports = handler