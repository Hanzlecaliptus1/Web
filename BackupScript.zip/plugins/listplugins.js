/*
  FITUR LIST PLUGINS (CommonJS)
  Fungsi: Menampilkan daftar file plugin yang aktif di database bot.
  Akses: Khusus Owner (Karena ini informasi teknis).
*/

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
    // 1. Validasi Owner (Opsional, tapi disarankan)
    if (!isOwner) return m.reply('❌ Fitur ini khusus Owner untuk mengecek file sistem.');

    // 2. Ambil Data Plugins dari Global Variable
    // Hampir semua base bot (Baileys) menyimpan plugin di global.plugins
    let plugins = Object.keys(global.plugins);
    let total = plugins.length;

    // 3. Fitur Search (Filter)
    // Jika user mengetik: .listplugin game
    // Maka hanya muncul plugin yang mengandung kata "game"
    if (text) {
        let search = text.toLowerCase();
        plugins = plugins.filter(p => p.toLowerCase().includes(search));
    }

    // 4. Sorting (Urutkan A-Z)
    plugins.sort();

    // 5. Susun Pesan Tampilan
    let header = `📂 *DATABASE PLUGINS*\n` +
                 `📊 *Total File:* ${total}\n` +
                 (text ? `🔍 *Filter:* "${text}"\n` : ``) +
                 `──────────────────\n`;

    let body = '';
    
    if (plugins.length === 0) {
        body = '⚠️ Tidak ada plugin yang ditemukan dengan kata kunci tersebut.';
    } else {
        // Looping daftar file
        plugins.forEach((plugin, index) => {
            // Bersihkan path agar hanya nama file yang muncul
            // Misal: '/home/container/plugins/menu.js' -> 'plugins/menu.js'
            let shortName = plugin.replace(/^.*[\\/]/, ''); 
            
            // Format: 1. nama_file.js
            body += `${index + 1}. ${shortName}\n`;
        });
    }

    let footer = `\n_Gunakan *${usedPrefix}getplugin <namafile>* untuk mengambil isinya._`;

    // 6. Kirim Hasil
    await m.reply(header + body + footer);
};

handler.help = ['listplugin', 'plugins'];
handler.tags = ['owner', 'host'];
handler.command = /^(listplugin|listplugins|plug|plugins)$/i;
handler.owner = true;

module.exports = handler;