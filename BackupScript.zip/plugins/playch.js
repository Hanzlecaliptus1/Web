/*
• Nama Fitur : PlayCh
• Type : Plugin CommonJS
• Link Channel : /0029VbB8WYS4CrfhJCelw33j
• Author : Agas (Converted by AI)
*/

const axios = require('axios');
const fs = require('fs');
const { spawn } = require('child_process');
const FormData = require('form-data');
const path = require('path');

// Fungsi Convert MP3 ke Opus menggunakan FFmpeg Spawn
function mp3ToOpus(buffer) {
  return new Promise((resolve, reject) => {
    // Gunakan nama file acak agar tidak bentrok jika banyak user memakai fitur ini
    const randomId = Date.now() + Math.floor(Math.random() * 1000);
    const tmpIn = path.join('./tmp', `${randomId}_in.mp3`);
    const tmpOut = path.join('./tmp', `${randomId}_out.opus`);

    // Pastikan folder tmp ada
    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');

    fs.writeFileSync(tmpIn, buffer);

    const ffmpeg = spawn('ffmpeg', [
      '-y',
      '-i', tmpIn,
      '-c:a', 'libopus',
      '-b:a', '128k',
      tmpOut
    ]);

    ffmpeg.on('close', (code) => {
      try {
        if (code !== 0) {
            if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
            return reject(new Error('FFmpeg gagal convert'));
        }
        const out = fs.readFileSync(tmpOut);
        
        // Bersihkan file sampah
        if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
        if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
        
        resolve(out);
      } catch (e) {
        reject(e);
      }
    });

    ffmpeg.on('error', (e) => {
        if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
        reject(e);
    });
  });
}

// Fungsi Upload ke Deline
async function uploadDeline(buffer, filename = 'file.opus', mime = 'audio/ogg') {
  const fd = new FormData();
  // Format append yang benar untuk library 'form-data' di Node.js
  fd.append('file', buffer, { filename: filename, contentType: mime });

  const res = await axios.post('https://api.deline.web.id/uploader', fd, {
    maxBodyLength: 50 * 1024 * 1024,
    maxContentLength: 50 * 1024 * 1024,
    headers: {
        ...fd.getHeaders() // Penting untuk form-data di Node.js
    }
  });

  const data = res.data || {};
  if (data.status === false) throw new Error(data.message || data.error || 'Upload failed');
  
  const link = data?.result?.link || data?.url || data?.path;
  if (!link) throw new Error('Invalid response (no link found)');
  
  return link;
}

let handler = async (m, { text, command, usedPrefix, conn }) => {
  if (!text) throw `Contoh:\n${usedPrefix + command} kau masih kekasihku\n${usedPrefix + command} The night we meet`;

  m.reply('🚀 Otw mencari & mengkonversi...');

  try {
    // 1. Ambil Metadata & Link Download
    const api = `https://api.deline.web.id/downloader/ytplay?q=${encodeURIComponent(text)}`;
    const { data } = await axios.get(api, { timeout: 180000 });

    if (!data?.status || !data?.result) throw new Error('❌ Gagal mengambil data metadata.');
    const { title, url: videoUrl, thumbnail, pick, dlink } = data.result;
    
    if (!dlink) throw new Error('❌ Link audio tidak tersedia dari API.');

    // 2. Konfigurasi Channel
    const author = 'Hanz';
    const channelId = '120363400444882911@newsletter'; // Pastikan ID ini benar
    const channelName = 'cuman bahan gabutnya?';

    const contextInfo = {
      forwardingScore: 1,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: channelId,
        serverMessageId: null,
        newsletterName: channelName
      },
      externalAdReply: {
        title: title || 'YouTube Audio',
        body: author,
        thumbnailUrl: thumbnail || (global.thumbmenu ? global.thumbmenu : 'https://telegra.ph/file/2a06381fd44658718494c.jpg'), // Fallback thumb
        mediaType: 1,
        sourceUrl: videoUrl || 'https://youtube.com',
        renderLargerThumbnail: false
      }
    };

    // 3. Download Audio (MP3)
    const audioRes = await axios.get(dlink, { responseType: 'arraybuffer', timeout: 180000 });
    const mp3Buffer = Buffer.from(audioRes.data);

    // 4. Convert MP3 ke Opus (PTT Format)
    const opusBuf = await mp3ToOpus(mp3Buffer);

    // 5. Upload Opus ke Server agar mendapatkan URL publik
    const safeTitle = title.replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_');
    const opusUrl = await uploadDeline(opusBuf, `${safeTitle}.opus`, 'audio/ogg');

    // 6. Kirim ke Channel
    await conn.sendMessage(channelId, {
      audio: { url: opusUrl },
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true,
      contextInfo
    });

    m.reply(`✅ Sukses kirim VN ke channel\n• Judul: ${title}\n• Kualitas: ${pick?.quality || '128kbps'}`);

  } catch (err) {
    console.error('❌ Gagal PlayCh:', err);
    m.reply('❌ Gagal kirim vn ke channel.\n\nError: ' + (err?.message || 'Tidak diketahui'));
  }
};

handler.help = ['playch'];
handler.tags = ['owner'];
handler.command = /^playch$/i;
handler.owner = true;

module.exports = handler;