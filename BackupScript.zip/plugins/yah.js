const os = require('os');
const { performance } = require('perf_hooks');

let handler = async (m, { conn }) => {
  // 1. Menghitung Kecepatan Respon
  const start = performance.now();
  const ramTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
  const ramFree = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
  const end = performance.now();
  const latensi = (end - start).toFixed(3);

  // 2. Pesan Informasi
  const infoText = `
🚀 *SPEED TEST*
Latency: *${latensi} ms*

💻 *SERVER INFO*
RAM: ${ramFree}GB / ${ramTotal}GB
OS: ${os.platform()} - ${os.release()}
Uptime: ${(os.uptime() / 3600).toFixed(1)} Jam
  `.trim();

  // --- OPSI 1: FAKE REPLY BIASA (Reply Status WA) ---
  // Ini membuat bot seolah-olah me-reply status whatsapp
  const fakeStatus = {
    key: {
      fromMe: false,
      participant: '0@s.whatsapp.net', // 0@s.whatsapp.net adalah ID untuk Status WA
      remoteJid: 'status@broadcast'
    },
    message: {
      conversation: '⭐ HANZ SYSTEM ONLINE ⭐' // Teks yang muncul di quote
    }
  };

  // --- OPSI 2: FAKE REPLY DENGAN GAMBAR BESAR (Ad Reply) ---
  // Ini membuat tampilan lebih keren dengan thumbnail
  const contextInfo = {
    externalAdReply: {
      title: "HANZ - BOT SPEED",
      body: `Speed: ${latensi}ms`,
      mediaType: 1,
      renderLargerThumbnail: true,
      thumbnailUrl: "https://telegra.ph/file/9e63b72180dd69f0af550-f628bf658fc0b0bb8a.jpg", // Ganti dengan link gambar Anda
      sourceUrl: "https://hanz-payment-phi.vercel.app/" // Link grup/web Anda
    }
  };

  // ====================================================
  // PILIH SALAH SATU CARA KIRIM DI BAWAH INI:
  // ====================================================

  // CARA A: Kirim dengan Fake Quote Status (Lebih Ringan)
  await conn.sendMessage(m.chat, { text: infoText }, { quoted: fakeStatus });

  /* // CARA B: Kirim dengan Gambar Besar (Lebih Keren)
  // Jika ingin pakai cara ini, hapus tanda komentar (//) di bawah & komentari Cara A
  
  await conn.sendMessage(m.chat, { 
    text: infoText,
    contextInfo: contextInfo 
  }, { quoted: m });
  */
};

handler.help = ['ping', 'speed'];
handler.command = /^(poong|speed|test)$/i;
handler.tags = ['info'];

module.exports = handler;