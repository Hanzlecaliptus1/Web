/**
 * Plugin: spampairing
 * Purpose: Controlled spam sender for pairing/testing in the current chat.
 * Safety: owner-only, hard limits (maxCount, minInterval), and stop command.
 *
 * Usage:
 *   .spampairing start <count> <interval_ms> <message...>
 *     - count: number of messages to send (max 50)
 *     - interval_ms: interval in milliseconds between messages (min 500)
 *     - message: the message text to spam (can include placeholders)
 *     Example: .spampairing start 5 2000 Siap pairing! 🎯
 *
 *   .spampairing stop
 *     - stops an ongoing spampairing in the chat
 *
 * Notes:
 * - This plugin intentionally only operates in the chat where the command is issued.
 * - It's owner-only to prevent abuse. Owner list is read from global.owner (array of JIDs or strings).
 * - All sent messages quoted the command message so it's traceable in chat history.
 */

let handler = async (m, { conn, usedPrefix: _p, args }) => {
  try {
    // Ensure global state object
    global.spampairing = global.spampairing || {}

    // owner check: supports global.owner as array of JIDs or phone strings
    const owners = Array.isArray(global.owner) ? global.owner.map(v => (v || '').toString()) : []
    const senderId = m.sender && m.sender.toString()
    if (!owners.includes(senderId) && !owners.includes(senderId.split`@`[0])) {
      return conn.reply(m.chat, 'Maaf, fitur ini khusus untuk owner bot.', m)
    }

    const sub = (args[0] || '').toLowerCase()
    if (!sub || (sub !== 'start' && sub !== 'stop')) {
      const helpMsg =
`Cara pakai spampairing:
• ${_p}spampairing start <count> <interval_ms> <message...>
  Contoh: ${_p}spampairing start 5 2000 Siap pairing! 🎯
• ${_p}spampairing stop
Peringatan: count max 50, interval min 500ms. Hanya owner yang dapat menjalankan.`
      return conn.reply(m.chat, helpMsg, m)
    }

    // Stop command
    if (sub === 'stop') {
      const state = global.spampairing[m.chat]
      if (!state || !state.interval) return conn.reply(m.chat, 'Tidak ada spampairing yang sedang berjalan di chat ini.', m)
      clearInterval(state.interval)
      delete global.spampairing[m.chat]
      return conn.reply(m.chat, 'Spampairing dihentikan.', m)
    }

    // Start command
    // parse args: start <count> <interval_ms> <message...>
    let count = parseInt(args[1]) || 5
    let intervalMs = parseInt(args[2]) || 2000
    let message = args.slice(3).join(' ') || '🚀 Pairing...'

    // limits to prevent abuse
    const MAX_COUNT = 50
    const MIN_INTERVAL = 500

    if (count <= 0) return conn.reply(m.chat, 'Jumlah pesan harus lebih dari 0.', m)
    if (count > MAX_COUNT) return conn.reply(m.chat, `Maksimal jumlah pesan adalah ${MAX_COUNT}.`, m)
    if (intervalMs < MIN_INTERVAL) return conn.reply(m.chat, `Interval minimal adalah ${MIN_INTERVAL} ms.`, m)

    // prevent multiple spampairing in same chat
    if (global.spampairing[m.chat] && global.spampairing[m.chat].interval) {
      return conn.reply(m.chat, 'Spampairing sudah berjalan di chat ini. Hentikan terlebih dahulu dengan perintah stop.', m)
    }

    // prepare state
    let sent = 0
    const quoted = m
    const jid = m.chat

    // create interval sender
    const interval = setInterval(async () => {
      try {
        if (sent >= count) {
          clearInterval(interval)
          delete global.spampairing[jid]
          // final ack
          await conn.sendMessage(jid, { text: `✅ Spampairing selesai. Terkirim ${sent} pesan.` }, { quoted })
          return
        }
        // You may customize the message template further (e.g., include index)
        const finalMsg = message.replace(/%n/g, String(sent + 1)).replace(/%total/g, String(count))
        await conn.sendMessage(jid, { text: finalMsg }, { quoted })
        sent++
      } catch (e) {
        console.error('spampairing error:', e)
        clearInterval(interval)
        delete global.spampairing[jid]
        await conn.sendMessage(jid, { text: '⚠️ Terjadi kesalahan saat mengirim spampairing. Menghentikan.' }, { quoted }).catch(() => {})
      }
    }, intervalMs)

    // save state
    global.spampairing[m.chat] = { interval, count, intervalMs, startedAt: Date.now() }

    // ack start
    return conn.reply(m.chat, `🚀 Memulai spampairing: ${count} pesan, setiap ${intervalMs} ms.\nKirim "${_p}spampairing stop" untuk menghentikan.`, m)
  } catch (err) {
    console.error(err)
    return conn.reply(m.chat, 'Terjadi error saat menjalankan spampairing.', m)
  }
}

handler.help = ['spampairing']
handler.tags = ['owner']
handler.command = /^(spampairing)$/i
handler.owner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false
handler.limit = false
handler.exp = 0

module.exports = handler