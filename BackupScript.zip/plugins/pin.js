/*
  FITUR PINTEREST SLIDE (Carousel)
  Fungsi: Menampilkan hasil pencarian Pinterest dalam bentuk kartu geser.
  API: Botcahx
*/

const fetch = require('node-fetch');
const { 
    generateWAMessageFromContent, 
    proto, 
    prepareWAMessageMedia 
} = require('@adiwajshing/baileys');

let handler = async (m, { usedPrefix, command, conn, text }) => {
    if (!text) throw `*🚩 Example:* ${usedPrefix}${command} Zhao Lusi`;
    
    m.reply(global.wait || '⏳ Sedang memuat...');

    try {
        // Menggunakan API Key global.btc (sesuai script asalmu) atau fallback ke string kosong
        const apikey = global.btc || 'Isi_Apikey_Botcahx_Disini'; 
        
        // Fetch Data
        let response = await fetch(`https://api.botcahx.eu.org/api/search/pinterest?text1=${encodeURIComponent(text)}&apikey=${apikey}`);
        let data = await response.json();

        if (!data.result || data.result.length === 0) throw '❌ Gambar tidak ditemukan.';

        // Batasi jumlah slide (Max 5-7 agar tidak berat saat render)
        let limit = Math.min(6, data.result.length);
        let images = data.result.slice(0, limit);
        let cards = [];

        // Loop untuk membuat setiap Kartu Slide
        for (let i = 0; i < images.length; i++) {
            let url = images[i];
            
            // Siapkan Media Gambar
            let media = await prepareWAMessageMedia(
                { image: { url: url } }, 
                { upload: conn.waUploadToServer }
            );

            // Masukkan ke array cards
            cards.push({
                body: proto.Message.InteractiveMessage.Body.create({
                    text: `📌 *Pinterest Slide* (${i + 1}/${limit})\n🔎 Query: ${text}`
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "© Hanz Bot"
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                    title: "",
                    subtitle: "",
                    hasMediaAttachment: true,
                    ...media // Pasang gambar di header
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [
                        {
                            "name": "cta_url",
                            "buttonParamsJson": JSON.stringify({
                                "display_text": "🔗 Lihat Gambar Asli",
                                "url": url,
                                "merchant_url": url
                            })
                        }
                    ]
                })
            });
        }

        // Buat Pesan Carousel
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `✨ Ditemukan *${data.result.length}* hasil untuk "${text}".\nGeser kartu di bawah untuk melihat:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "Powered by Botcahx"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            hasMediaAttachment: false
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({
                            cards: cards
                        })
                    })
                }
            }
        }, { userJid: m.chat, quoted: m });

        // Kirim Pesan
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
        console.error(e);
        throw '❌ Terjadi kesalahan atau API Key limit.';
    }
}

handler.help = ['pinterest <keyword>'];
handler.tags = ['internet'];
handler.command = /^(pinterest|pin1)$/i;

module.exports = handler;